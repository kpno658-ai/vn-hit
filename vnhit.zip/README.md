# VNHIT v1.0 — Native Android Productivity Suite

**VNHIT v1.0** is a native, offline-first Android productivity powerhouse built with Kotlin, Jetpack Compose, Material 3, and Room SQLite Database. It unites four essential productivity disciplines into a seamless, futuristic cyber-minimalist dashboard.

---

## 🚀 Features

### 1. 📝 Notes & Intel
- **Create, Read, Update, Delete**: Instant local storage for ideas, code snippets, and agendas.
- **Real-Time Search**: Search through note titles and contents with live reactive querying.
- **Categorization**: Filter notes across General, Work, Ideas, Study, and Personal tags.
- **Pin to Top**: Keep mission-critical notes anchored at the top.
- **Safety Confirmations**: Deletion dialogs prevent accidental data loss.

### 2. ⚡ Habit Engine & Mathematical Streak Tracker
- **Streak Calculation**: Calculates consecutive streaks and historical personal bests across calendar boundaries.
- **Daily One-Tap Completion**: Toggle daily routine habits directly from the dashboard or habit manager.
- **7-Day Mini Heatmap**: Visual audit of the last 7 days of consistency.
- **Gamification & Badges**: Unlock milestones (Starter, Ignition, 3-Day Surge, Mastery, Titan).
- **Persistent Progress**: Room SQLite schema with unique compound indices on `(habitId, date)`.

### 3. ⏱️ Precision Focus Protocol (Pomodoro / Deep Work)
- **Presets**: 5m (Sprint/Break), 15m, 25m (Standard Pomodoro), 45m (Deep Work), plus Custom duration (1–180 minutes).
- **Precision Hardware-Clock Math**: Avoids inaccurate frame-by-frame recomposition drift by calculating remaining time against target epoch timestamps.
- **Lifecycle-Safe Controls**: Start, pause, resume, and reset.
- **Post-Session Routine**: Prompts for a 5-minute break upon completion.
- **Focus Log & History**: Every completed session logs duration, type, and completion timestamp to the local database.

### 4. 📅 Calendar & Event Timeline
- **Interactive Month Calendar**: Navigate months with `<` and `>`, return to `Today` with one tap.
- **Event Dots**: Days with scheduled tasks display cyan event indicators.
- **Date Inspector**: Tap any date to view and manage events scheduled for that day.
- **In-App Local Events**: Start time, end time, category, title, and location/description.
- **Input Validation**: Verifies date formats (YYYY-MM-DD), start/end times, and non-empty titles.

### 5. 🎙️ VN Assistant (Virtual Natural Language Assistant)
- **Natural Language Command Engine**: Deterministic on-device intent parser matching actions in English, Hindi, Hinglish, Spanish, French, German, Bengali, and Tamil.
- **Voice Input & TTS Output**: Native Android `SpeechRecognizer` with permission handling and `TextToSpeech` with language locale configuration and mute controls.
- **Warm Spoken Audio Intro**: Integrated audio greeting (`res/raw/welcome_greeting.mp3`) with lifecycle-safe `AudioPlayerUtil` and audio focus handling.
- **Animated Assistant Orb**: Breathing radial gradient orb with listening, speaking, and idle state animations.
- **Transcript History**: Conversational message bubbles with executed action tags and suggestion chips.

### 6. ⚙️ System Settings & Device Optimization
- **Multilingual Localization**: Preferred language selector and auto-detection toggle.
- **Appearance Modes**: Midnight Aurora (default), Deep Obsidian, Cyber Neon, and Light Horizon.
- **Low-End Phone Mode**: Reduced motion toggle disables intensive animations to maximize battery life on modest hardware.
- **Target Refresh Rate**: 60Hz (Battery Saver), 90Hz (Smooth), and 120Hz (Ultra) display settings.
- **On-Device AI Package Verification**: Transparent candidate model information (Qwen2.5-0.5B-Instruct quantized ~380MB) and local cache initialization.
- **Local Storage Management**: SQLite database stats, JSON export to clipboard, and safe data purge with confirmation.
- **Voluntary Support Card**: "Buy Me a Coffee" support card with zero feature restrictions.

### 7. 🛸 Master Dashboard
- **Daily Motivational Slogan**: “Small steps. Quiet rewards. Real progress.”
- **Live Productivity Metrics**: Real-time habit completion rates, logged focus minutes, total notes, and next events.
- **Embedded Mini-Timer & Routine Widgets**: Control your focus countdown and check off daily habits directly from the home screen.
- **VN Assistant Quick Launcher**: One-tap access to voice assistant or spoken greeting.

---

## 🎨 Design System

- **Main Background**: Deep Navy (`#080D1B`)
- **Card Surface**: Dark Blue-Gray (`#111A2D`)
- **Elevated Surface**: (`#18233C` / `#1F2C4A`)
- **Primary Accent**: Electric Cyan (`#55E6FF`)
- **Secondary Accent**: Cyber Violet (`#9A7BFF`)
- **Success / Streaks**: Neon Mint (`#00E676`) & Solar Orange (`#FF7A45`)
- **Typography & Components**: Modern Material Design 3 with custom adaptive launcher icon.

---

## 🛠️ Tech Stack & Architecture

- **Language**: Kotlin 2.2+
- **UI Toolkit**: Jetpack Compose with Material 3 (BOM 2024.09.00)
- **Database**: AndroidX Room 2.7.0 with Kotlin Symbol Processing (KSP)
- **Architecture**: Clean MVVM (Model-View-ViewModel) with Repository pattern and Kotlin Coroutines/Flow
- **Testing**: JUnit 4 and Robolectric 4.16+
- **Min SDK**: API 24 (Android 7.0+)
- **Target SDK**: API 36

---

## 📦 Building and Running the Project

### Prerequisites
- Android Studio Ladybug (2024.2+) or newer
- JDK 17 or JDK 21

### Building from Android Studio
1. Open Android Studio and select **Open**.
2. Navigate to the project root directory and select `build.gradle.kts`.
3. Allow Gradle to sync dependencies.
4. Select a connected physical device or Android Virtual Device (AVD).
5. Click **Run** (`Shift + F10`) or **Debug**.

### Building via Command Line
```bash
# Compile and build the debug APK
gradle :app:assembleDebug

# The generated APK will be located at:
# app/build/outputs/apk/debug/app-debug.apk

# Run unit and Robolectric tests
gradle :app:testDebugUnitTest
```

---

## 🧪 Testing Scenarios Verified
1. **Note Persistence**: Creating notes, searching by keyword, updating, and verifying persistence.
2. **Streak Calculations**: Accurate calculation of active streaks when completed today, completed yesterday, or broken by gaps.
3. **Focus Timer Accuracy**: Verified timestamp-based countdown calculation.
4. **Calendar Validation**: Safe handling of dates, times, and scheduling without crashes.
5. **Back Navigation**: Sub-screens safely handle Android back gesture to return to Home.
