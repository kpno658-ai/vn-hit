package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NavTab
import com.example.ui.VnhitViewModel
import com.example.ui.screens.AssistantScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.HabitsScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.VnhitBackground
import com.example.ui.theme.VnhitBorder
import com.example.ui.theme.VnhitCyan
import com.example.ui.theme.VnhitSurface
import com.example.ui.theme.VnhitTextMuted
import com.example.ui.theme.VnhitTextSecondary
import com.example.ui.theme.VnhitTheme

class MainActivity : ComponentActivity() {

    private val viewModel: VnhitViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val currentTheme by viewModel.selectedTheme.collectAsState()
            VnhitTheme(themeMode = currentTheme) {
                VnhitMainApp(viewModel = viewModel)
            }
        }
    }
}

private data class NavItemData(
    val tab: NavTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun VnhitMainApp(viewModel: VnhitViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    // Handle back button: if not on Dashboard, navigate back to Dashboard
    BackHandler(enabled = currentTab != NavTab.DASHBOARD) {
        viewModel.navigateTo(NavTab.DASHBOARD)
    }

    val navItems = listOf(
        NavItemData(NavTab.DASHBOARD, "Home", Icons.Filled.Dashboard, Icons.Outlined.Dashboard, "nav_tab_dashboard"),
        NavItemData(NavTab.NOTES, "Notes", Icons.Filled.Description, Icons.Outlined.Description, "nav_tab_notes"),
        NavItemData(NavTab.HABITS, "Habits", Icons.Filled.TaskAlt, Icons.Outlined.TaskAlt, "nav_tab_habits"),
        NavItemData(NavTab.FOCUS, "Focus", Icons.Filled.Timer, Icons.Outlined.Timer, "nav_tab_focus"),
        NavItemData(NavTab.CALENDAR, "Calendar", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_tab_calendar"),
        NavItemData(NavTab.ASSISTANT, "VN", Icons.Filled.RecordVoiceOver, Icons.Outlined.RecordVoiceOver, "nav_tab_assistant"),
        NavItemData(NavTab.SETTINGS, "Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_tab_settings")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .border(0.5.dp, MaterialTheme.colorScheme.outline)
                    .testTag("main_navigation_bar")
            ) {
                navItems.forEach { item ->
                    val isSelected = currentTab == item.tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(item.tab) },
                        alwaysShowLabel = false,
                        icon = {
                            Icon(
                                imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.label,
                                tint = if (isSelected) Color(0xFF00363F) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 10.sp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primary,
                            selectedIconColor = Color(0xFF00363F),
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(item.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavTab.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                NavTab.NOTES -> NotesScreen(viewModel = viewModel)
                NavTab.HABITS -> HabitsScreen(viewModel = viewModel)
                NavTab.FOCUS -> FocusScreen(viewModel = viewModel)
                NavTab.CALENDAR -> CalendarScreen(viewModel = viewModel)
                NavTab.ASSISTANT -> AssistantScreen(viewModel = viewModel)
                NavTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
