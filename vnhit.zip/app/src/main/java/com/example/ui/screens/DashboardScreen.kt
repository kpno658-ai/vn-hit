package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.NavTab
import com.example.ui.TimerSessionType
import com.example.ui.VnhitViewModel
import com.example.ui.components.SectionHeader
import com.example.ui.components.VnhitCard
import com.example.ui.theme.Slate100
import com.example.ui.theme.Slate300
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate500
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950
import com.example.ui.theme.VnhitAmber
import com.example.ui.theme.VnhitBackground
import com.example.ui.theme.VnhitBlue
import com.example.ui.theme.VnhitBorder
import com.example.ui.theme.VnhitBorderSubtle
import com.example.ui.theme.VnhitCyan
import com.example.ui.theme.VnhitPink
import com.example.ui.theme.VnhitSuccess
import com.example.ui.theme.VnhitSurface
import com.example.ui.theme.VnhitSurfaceElevated
import com.example.ui.theme.VnhitSurfaceVariant
import com.example.ui.theme.VnhitTextMuted
import com.example.ui.theme.VnhitTextPrimary
import com.example.ui.theme.VnhitTextSecondary
import com.example.ui.theme.VnhitViolet
import com.example.ui.theme.VnhitWarning
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.productivitySummary.collectAsState()
    val habits by viewModel.habitsList.collectAsState()
    val notes by viewModel.notesList.collectAsState()
    val upcomingEvents by viewModel.upcomingEvents.collectAsState()
    val refreshRate by viewModel.refreshRate.collectAsState()

    val currentTimeStr = remember {
        val sdf = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US)
        sdf.format(Date())
    }

    val totalHabits = summary.habitsCount
    val completedHabits = summary.habitsCompletedToday
    val habitScore = if (totalHabits > 0) (completedHabits.toFloat() / totalHabits) * 70f else 0f
    val focusScore = (summary.totalFocusMinutes * 1.2f).coerceAtMost(30f)
    val totalScore = (habitScore + focusScore).coerceIn(0f, 100f).toInt()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VnhitBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ==========================================
        // 1. APP TOP HEADER (Exact Simulator Header)
        // ==========================================
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Gradient Icon Badge
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(VnhitCyan, VnhitViolet, VnhitPink)
                            )
                        )
                        .padding(1.5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Slate950),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "VNHIT",
                            tint = VnhitCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // App Title & Subtitle
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "VNHIT",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = VnhitCyan
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = VnhitCyan.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, VnhitCyan.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = "v1.0",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = VnhitCyan,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = "Midnight Aurora Engine",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Slate400,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                // Refresh Rate Pill & Settings Gear
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = VnhitCyan.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VnhitCyan.copy(alpha = 0.3f)),
                    modifier = Modifier.padding(end = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(VnhitCyan)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = refreshRate.substringBefore(" "),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitCyan,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.playWelcomeVoice() },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(VnhitSurfaceElevated)
                        .border(1.dp, VnhitBorder, CircleShape)
                        .testTag("dashboard_audio_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Welcome Audio",
                        tint = Slate300,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = { viewModel.navigateTo(NavTab.SETTINGS) },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(VnhitSurfaceElevated)
                        .border(1.dp, VnhitBorder, CircleShape)
                        .testTag("dashboard_settings_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = Slate300,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // ==========================================
        // 2. GREETING BANNER (Midnight Aurora Glass)
        // ==========================================
        item {
            VnhitCard(
                borderColor = VnhitCyan.copy(alpha = 0.25f),
                backgroundColor = VnhitSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "GOOD DAY, OPERATOR",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = VnhitCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    fontSize = 10.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = currentTimeStr,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Slate300
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "\"Precision in execution builds quiet momentum.\"",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Slate400,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        // Fire Momentum Badge
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(VnhitAmber.copy(alpha = 0.15f))
                                .border(1.dp, VnhitAmber.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Momentum",
                                tint = VnhitAmber,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 3. DAILY COMPLETION MATRIX CARD
        // ==========================================
        item {
            VnhitCard(
                borderColor = VnhitBorder,
                backgroundColor = VnhitSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PieChart,
                                contentDescription = null,
                                tint = VnhitPink,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "DAILY COMPLETION MATRIX",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Slate300,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Text(
                            text = "$totalScore%",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = VnhitCyan
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        // Multi-color Gradient Progress Ring
                        Box(
                            modifier = Modifier.size(108.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val strokeWidth = 8.dp.toPx()
                                // Background ring
                                drawCircle(
                                    color = Color(0x14FFFFFF),
                                    style = Stroke(width = strokeWidth)
                                )
                                // Aurora Gradient arc
                                val sweep = (totalScore / 100f) * 360f
                                drawArc(
                                    brush = Brush.sweepGradient(
                                        listOf(VnhitCyan, VnhitViolet, VnhitPink, VnhitCyan)
                                    ),
                                    startAngle = -90f,
                                    sweepAngle = sweep,
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = "$totalScore",
                                        style = MaterialTheme.typography.headlineSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color.White
                                        )
                                    )
                                    Text(
                                        text = "%",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = VnhitCyan,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(bottom = 3.dp)
                                    )
                                }
                                Text(
                                    text = "SCORE",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Slate400,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                        }

                        // Right-hand Dual Stat Counters
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Habits Checked Counter
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Slate900.copy(alpha = 0.6f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.width(150.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(VnhitCyan)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Habits Checked",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = Slate400,
                                                fontSize = 10.sp
                                            )
                                        )
                                        Text(
                                            text = "$completedHabits / $totalHabits",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = Color.White,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }

                            // Focus Sprints Counter
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Slate900.copy(alpha = 0.6f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                                modifier = Modifier.width(150.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(VnhitPink)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Focus Sprints",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = Slate400,
                                                fontSize = 10.sp
                                            )
                                        )
                                        Text(
                                            text = "${summary.totalFocusMinutes} min",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = Color.White,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 4. QUICK LAUNCH SHORTCUTS (Grid of 3)
        // ==========================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Start Focus
                VnhitCard(
                    modifier = Modifier.weight(1f),
                    borderColor = VnhitCyan.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(18.dp),
                    onClick = {
                        viewModel.setTimerPreset(TimerSessionType.FOCUS_25)
                        viewModel.navigateTo(NavTab.FOCUS)
                        viewModel.startTimer()
                    }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(VnhitCyan.copy(alpha = 0.18f))
                                .border(1.dp, VnhitCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Focus",
                                tint = VnhitCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Start Focus",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Slate100
                            )
                        )
                    }
                }

                // Habits
                VnhitCard(
                    modifier = Modifier.weight(1f),
                    borderColor = VnhitPink.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(18.dp),
                    onClick = { viewModel.navigateTo(NavTab.HABITS) }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(VnhitPink.copy(alpha = 0.18f))
                                .border(1.dp, VnhitPink.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TaskAlt,
                                contentDescription = "Habits",
                                tint = VnhitPink,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Habits",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Slate100
                            )
                        )
                    }
                }

                // Add Note
                VnhitCard(
                    modifier = Modifier.weight(1f),
                    borderColor = VnhitViolet.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(18.dp),
                    onClick = {
                        viewModel.navigateTo(NavTab.NOTES)
                        viewModel.openNoteDialog(null)
                    }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(VnhitViolet.copy(alpha = 0.18f))
                                .border(1.dp, VnhitViolet.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Note",
                                tint = VnhitViolet,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Add Note",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Slate100
                            )
                        )
                    }
                }
            }
        }

        // ==========================================
        // 5. VNHIT INSIDER CARD (Exact Simulator Design)
        // ==========================================
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = VnhitSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, VnhitBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(84.dp)
                            .background(VnhitViolet)
                    )
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "VNHIT INSIDER",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = VnhitViolet,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            )
                            Text(
                                text = "v1.0 Release",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Slate500,
                                    fontSize = 10.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Full Offline-First Engine Active",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "All data is preserved securely in your device's local Room SQLite cache with zero external telemetry latency.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Slate400,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }

        // ==========================================
        // 6. BUY ME A COFFEE UPI SUPPORT BANNER
        // ==========================================
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = VnhitSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, VnhitAmber.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(NavTab.SETTINGS) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    VnhitAmber.copy(alpha = 0.08f),
                                    VnhitPink.copy(alpha = 0.08f),
                                    VnhitViolet.copy(alpha = 0.08f)
                                )
                            )
                        )
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(VnhitAmber.copy(alpha = 0.18f))
                            .border(1.dp, VnhitAmber.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Coffee,
                            contentDescription = "Coffee",
                            tint = VnhitAmber,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Buy Me a Coffee ☕",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFDE68A)
                            )
                        )
                        Text(
                            text = "Support developer (₹5 - ₹100 UPI)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Slate300,
                                fontSize = 10.sp
                            )
                        )
                    }

                    Button(
                        onClick = { viewModel.navigateTo(NavTab.SETTINGS) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = VnhitAmber,
                            contentColor = Slate950
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Support",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black)
                        )
                    }
                }
            }
        }

        // ==========================================
        // 7. VN ASSISTANT QUICK LAUNCHER
        // ==========================================
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = VnhitSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, VnhitCyan.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(NavTab.ASSISTANT) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(listOf(VnhitCyan, VnhitViolet))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "VN Assistant",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "VN Assistant",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Slate100
                            )
                        )
                        Text(
                            text = "Voice & natural language control · 100% Offline",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Slate400,
                                fontSize = 11.sp
                            )
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = VnhitViolet.copy(alpha = 0.18f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VnhitViolet.copy(alpha = 0.4f)),
                        modifier = Modifier.clickable { viewModel.playWelcomeVoice() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = VnhitViolet,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Greeting",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = VnhitViolet,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // 8. TODAY'S ROUTINES
        // ==========================================
        item {
            SectionHeader(
                title = "Today's Routine",
                subtitle = "Tap to toggle daily completion",
                actionText = "View All",
                onActionClick = { viewModel.navigateTo(NavTab.HABITS) }
            )
        }

        if (habits.isEmpty()) {
            item {
                VnhitCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    onClick = { viewModel.openHabitDialog(null) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = null,
                            tint = VnhitCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "No habits created yet. Tap to start tracking!",
                            color = Slate400,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        } else {
            items(habits.take(3), key = { "dash_habit_${it.habit.id}" }) { item ->
                VnhitCard(
                    backgroundColor = VnhitSurface,
                    borderColor = if (item.isCompletedToday) VnhitCyan.copy(alpha = 0.5f) else VnhitBorder,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (item.isCompletedToday) VnhitCyan.copy(alpha = 0.2f) else Slate900)
                                .border(
                                    2.dp,
                                    if (item.isCompletedToday) VnhitCyan else Slate800,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    viewModel.toggleHabit(
                                        habitId = item.habit.id,
                                        currentStatus = item.isCompletedToday
                                    )
                                }
                                .testTag("dash_toggle_habit_${item.habit.id}"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (item.isCompletedToday) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = "Done",
                                    tint = VnhitCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.habit.name,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.isCompletedToday) Slate400 else Slate100
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.habit.category,
                                style = MaterialTheme.typography.labelSmall.copy(color = Slate500)
                            )
                        }

                        if (item.currentStreak > 0) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = VnhitAmber,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "${item.currentStreak}d",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = VnhitAmber,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
