package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.NoteEntity
import com.example.ui.VnhitViewModel
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.VnhitCard
import com.example.ui.theme.VnhitBackground
import com.example.ui.theme.VnhitBorder
import com.example.ui.theme.VnhitCyan
import com.example.ui.theme.VnhitError
import com.example.ui.theme.VnhitSurface
import com.example.ui.theme.VnhitSurfaceElevated
import com.example.ui.theme.VnhitSurfaceVariant
import com.example.ui.theme.VnhitTextMuted
import com.example.ui.theme.VnhitTextPrimary
import com.example.ui.theme.VnhitTextSecondary
import com.example.ui.theme.VnhitViolet
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NotesScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val notes by viewModel.notesList.collectAsState()
    val searchQuery by viewModel.noteSearchQuery.collectAsState()
    val isDialogOpen by viewModel.isNoteDialogOpen.collectAsState()
    val activeDialogNote by viewModel.noteDialogState.collectAsState()
    val noteToDelete by viewModel.noteToDelete.collectAsState()

    var selectedCategoryFilter by remember { mutableStateOf("All") }
    val categories = listOf("All", "General", "Work", "Ideas", "Study", "Personal")

    val filteredNotes = remember(notes, selectedCategoryFilter) {
        if (selectedCategoryFilter == "All") notes
        else notes.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = VnhitBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openNoteDialog(null) },
                containerColor = VnhitCyan,
                contentColor = Color(0xFF00363F),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_note_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Note")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Screen Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Notes & Intel",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = VnhitTextPrimary
                        )
                    )
                    Text(
                        text = "${notes.size} total notes saved locally",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setNoteSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_search_input"),
                placeholder = { Text("Search title or content...", color = VnhitTextMuted) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = VnhitCyan)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.setNoteSearchQuery("") },
                            modifier = Modifier.testTag("clear_note_search")
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear Search", tint = VnhitTextSecondary)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VnhitCyan,
                    unfocusedBorderColor = VnhitBorder,
                    focusedContainerColor = VnhitSurface,
                    unfocusedContainerColor = VnhitSurface,
                    focusedTextColor = VnhitTextPrimary,
                    unfocusedTextColor = VnhitTextPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                items(categories) { category ->
                    val isSelected = selectedCategoryFilter == category
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) VnhitCyan else VnhitSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, if (isSelected) VnhitCyan else VnhitBorder, RoundedCornerShape(20.dp))
                            .clickable { selectedCategoryFilter = category }
                            .testTag("note_filter_${category.lowercase()}")
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) Color(0xFF00363F) else VnhitTextSecondary,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Notes List or Empty State
            if (filteredNotes.isEmpty()) {
                EmptyStateView(
                    icon = Icons.Default.Description,
                    title = if (searchQuery.isNotEmpty()) "No matching notes" else "No notes yet",
                    description = if (searchQuery.isNotEmpty())
                        "Try a different search keyword or clear the search query."
                    else
                        "Capture your thoughts, ideas, plans, and code snippets locally with full offline persistence.",
                    actionButtonText = "+ Create First Note",
                    onActionClick = { viewModel.openNoteDialog(null) }
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredNotes, key = { it.id }) { note ->
                        NoteCardItem(
                            note = note,
                            onEdit = { viewModel.openNoteDialog(note) },
                            onDelete = { viewModel.requestDeleteNote(note) }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Dialog
    if (isDialogOpen && activeDialogNote != null) {
        NoteEditDialog(
            initialNote = activeDialogNote!!,
            onDismiss = { viewModel.closeNoteDialog() },
            onSave = { title, content, category, isPinned, colorTag ->
                viewModel.saveNote(
                    title = title,
                    content = content,
                    category = category,
                    isPinned = isPinned,
                    colorTag = colorTag,
                    id = activeDialogNote!!.id
                )
            }
        )
    }

    // Delete Confirmation
    if (noteToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Note?",
            message = "Are you sure you want to delete \"${noteToDelete!!.title.ifBlank { "Untitled Note" }}\"? This action cannot be undone.",
            onConfirm = { viewModel.confirmDeleteNote() },
            onDismiss = { viewModel.cancelDeleteNote() }
        )
    }
}

@Composable
fun NoteCardItem(
    note: NoteEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = remember(note.updatedAt) {
        SimpleDateFormat("MMM d, yyyy · hh:mm a", Locale.US).format(Date(note.updatedAt))
    }

    VnhitCard(
        onClick = onEdit,
        borderColor = if (note.isPinned) VnhitCyan else VnhitBorder,
        backgroundColor = VnhitSurface,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("note_card_${note.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Tag
                Text(
                    text = note.category.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = VnhitCyan,
                        fontSize = 10.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                )

                if (note.isPinned) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.PushPin,
                        contentDescription = "Pinned",
                        tint = VnhitCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Action buttons
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("edit_note_${note.id}")
                ) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Edit Note",
                        tint = VnhitTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("delete_note_${note.id}")
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete Note",
                        tint = VnhitError,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = note.title.ifBlank { "Untitled Note" },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = VnhitTextPrimary
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (note.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = note.content,
                    style = MaterialTheme.typography.bodyMedium.copy(color = VnhitTextSecondary),
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = dateStr,
                style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextMuted)
            )
        }
    }
}

@Composable
fun NoteEditDialog(
    initialNote: NoteEntity,
    onDismiss: () -> Unit,
    onSave: (title: String, content: String, category: String, isPinned: Boolean, colorTag: String) -> Unit
) {
    var title by remember { mutableStateOf(initialNote.title) }
    var content by remember { mutableStateOf(initialNote.content) }
    var category by remember { mutableStateOf(initialNote.category) }
    var isPinned by remember { mutableStateOf(initialNote.isPinned) }
    var colorTag by remember { mutableStateOf(initialNote.colorTag) }

    val categories = listOf("General", "Work", "Ideas", "Study", "Personal")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialNote.id == 0L) "New Note" else "Edit Note",
                color = VnhitTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Title", color = VnhitTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("note_title_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedContainerColor = VnhitSurfaceVariant,
                        unfocusedContainerColor = VnhitSurfaceVariant,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = { Text("Write content here...", color = VnhitTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .testTag("note_content_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedContainerColor = VnhitSurfaceVariant,
                        unfocusedContainerColor = VnhitSurfaceVariant,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Category", color = VnhitTextSecondary, style = MaterialTheme.typography.labelSmall)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        val isSelected = category == cat
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) VnhitCyan else VnhitSurfaceVariant,
                            modifier = Modifier
                                .border(1.dp, if (isSelected) VnhitCyan else VnhitBorder, RoundedCornerShape(14.dp))
                                .clickable { category = cat }
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) Color(0xFF00363F) else VnhitTextSecondary,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pin to top",
                        color = VnhitTextPrimary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = isPinned,
                        onCheckedChange = { isPinned = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = VnhitCyan,
                            checkedTrackColor = Color(0xFF004E5B)
                        ),
                        modifier = Modifier.testTag("note_pin_switch")
                    )
                }
            }
        },
        containerColor = VnhitSurface,
        confirmButton = {
            Button(
                onClick = { onSave(title, content, category, isPinned, colorTag) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = VnhitCyan,
                    contentColor = Color(0xFF00363F)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("save_note_button")
            ) {
                Text("Save", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("cancel_note_button")
            ) {
                Text("Cancel", color = VnhitTextSecondary)
            }
        }
    )
}
