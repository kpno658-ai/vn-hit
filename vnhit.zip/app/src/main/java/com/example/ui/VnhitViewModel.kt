package com.example.ui

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.assistant.AssistantMessage
import com.example.assistant.MessageSender
import com.example.assistant.VnAssistantIntent
import com.example.assistant.VnCommandEngine
import com.example.assistant.VnVoiceManager
import com.example.assistant.VoiceState
import com.example.data.database.VnhitDatabase
import com.example.data.entity.CalendarEventEntity
import com.example.data.entity.FocusSessionEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.NoteEntity
import com.example.data.repository.HabitWithProgress
import com.example.data.repository.ProductivitySummary
import com.example.data.repository.VnhitRepository
import com.example.ui.theme.AppThemeMode
import com.example.util.AudioPlayerUtil
import com.example.util.DateUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

enum class NavTab {
    DASHBOARD,
    NOTES,
    HABITS,
    FOCUS,
    CALENDAR,
    ASSISTANT,
    SETTINGS
}

enum class TimerSessionType(val displayName: String, val defaultMinutes: Int) {
    FOCUS_25("Focus (25m)", 25),
    FOCUS_15("Sprint (15m)", 15),
    FOCUS_45("Deep (45m)", 45),
    SHORT_BREAK("Short Break (5m)", 5),
    LONG_BREAK("Long Break (15m)", 15),
    CUSTOM("Custom", 25)
}

class VnhitViewModel(application: Application) : AndroidViewModel(application) {

    private val db = VnhitDatabase.getInstance(application)
    val repository = VnhitRepository(
        noteDao = db.noteDao(),
        habitDao = db.habitDao(),
        focusSessionDao = db.focusSessionDao(),
        calendarEventDao = db.calendarEventDao()
    )

    // Voice & Audio
    val voiceManager = VnVoiceManager(application)
    val audioPlayer = AudioPlayerUtil(application)

    // Current Navigation Tab
    private val _currentTab = MutableStateFlow(NavTab.DASHBOARD)
    val currentTab: StateFlow<NavTab> = _currentTab.asStateFlow()

    fun navigateTo(tab: NavTab) {
        _currentTab.value = tab
    }

    // ==========================================
    // SETTINGS STATE
    // ==========================================
    private val _selectedTheme = MutableStateFlow(AppThemeMode.MIDNIGHT_AURORA)
    val selectedTheme: StateFlow<AppThemeMode> = _selectedTheme.asStateFlow()

    private val _selectedLanguage = MutableStateFlow("en") // "en", "hi", "es", "fr", "de", "bn", "ta"
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _autoDetectLanguage = MutableStateFlow(true)
    val autoDetectLanguage: StateFlow<Boolean> = _autoDetectLanguage.asStateFlow()

    private val _voiceInputEnabled = MutableStateFlow(true)
    val voiceInputEnabled: StateFlow<Boolean> = _voiceInputEnabled.asStateFlow()

    private val _ttsRepliesEnabled = MutableStateFlow(true)
    val ttsRepliesEnabled: StateFlow<Boolean> = _ttsRepliesEnabled.asStateFlow()

    private val _reducedMotion = MutableStateFlow(false)
    val reducedMotion: StateFlow<Boolean> = _reducedMotion.asStateFlow()

    private val _refreshRate = MutableStateFlow("60Hz (Standard)")
    val refreshRate: StateFlow<String> = _refreshRate.asStateFlow()

    private val _quietHoursEnabled = MutableStateFlow(false)
    val quietHoursEnabled: StateFlow<Boolean> = _quietHoursEnabled.asStateFlow()

    private val _onDeviceModelInstalled = MutableStateFlow(false)
    val onDeviceModelInstalled: StateFlow<Boolean> = _onDeviceModelInstalled.asStateFlow()

    private val _isModelDownloading = MutableStateFlow(false)
    val isModelDownloading: StateFlow<Boolean> = _isModelDownloading.asStateFlow()

    private val _modelDownloadProgress = MutableStateFlow(0f)
    val modelDownloadProgress: StateFlow<Float> = _modelDownloadProgress.asStateFlow()

    fun setTheme(theme: AppThemeMode) {
        _selectedTheme.value = theme
    }

    fun setLanguage(langCode: String) {
        _selectedLanguage.value = langCode
    }

    fun setAutoDetectLanguage(enabled: Boolean) {
        _autoDetectLanguage.value = enabled
    }

    fun setVoiceInputEnabled(enabled: Boolean) {
        _voiceInputEnabled.value = enabled
    }

    fun setTtsRepliesEnabled(enabled: Boolean) {
        _ttsRepliesEnabled.value = enabled
    }

    fun setReducedMotion(enabled: Boolean) {
        _reducedMotion.value = enabled
    }

    fun setRefreshRate(rate: String) {
        _refreshRate.value = rate
    }

    fun setQuietHours(enabled: Boolean) {
        _quietHoursEnabled.value = enabled
    }

    fun startModelInstallation() {
        if (_isModelDownloading.value || _onDeviceModelInstalled.value) return
        _isModelDownloading.value = true
        _modelDownloadProgress.value = 0.05f

        viewModelScope.launch {
            // Simulated local model package verification without freezing or cloud dependency
            for (step in 1..10) {
                delay(250)
                _modelDownloadProgress.value = step * 0.10f
            }
            _isModelDownloading.value = false
            _onDeviceModelInstalled.value = true
            addAssistantMessage(
                AssistantMessage(
                    sender = MessageSender.ASSISTANT,
                    text = "Qwen2.5-0.5B-Instruct lightweight verification package initialized locally. Offline command execution ready."
                )
            )
        }
    }

    fun removeModel() {
        _onDeviceModelInstalled.value = false
        _modelDownloadProgress.value = 0f
    }

    // ==========================================
    // VN ASSISTANT STATE
    // ==========================================
    private val _assistantMessages = MutableStateFlow<List<AssistantMessage>>(
        listOf(
            AssistantMessage(
                sender = MessageSender.ASSISTANT,
                text = "Hello! I am VN Assistant (Virtual Natural Language Assistant). I can create notes, track habits, launch focus sessions, and schedule events. Try asking 'Start 25m focus', 'Create a note', or tap 'Play Voice Greeting'!"
            )
        )
    )
    val assistantMessages: StateFlow<List<AssistantMessage>> = _assistantMessages.asStateFlow()

    private val _isTranscriptExpanded = MutableStateFlow(false)
    val isTranscriptExpanded: StateFlow<Boolean> = _isTranscriptExpanded.asStateFlow()

    fun toggleTranscript() {
        _isTranscriptExpanded.value = !_isTranscriptExpanded.value
    }

    fun addAssistantMessage(message: AssistantMessage) {
        _assistantMessages.value = _assistantMessages.value + message
    }

    fun playWelcomeVoice() {
        audioPlayer.playWelcomeGreeting(
            onStarted = {
                addAssistantMessage(
                    AssistantMessage(
                        sender = MessageSender.ASSISTANT,
                        text = "Playing VNHIT welcome greeting...",
                        executedAction = "VOICE_GREETING"
                    )
                )
            }
        )
    }

    fun executeAssistantCommand(userInput: String) {
        if (userInput.isBlank()) return
        val userMsg = AssistantMessage(sender = MessageSender.USER, text = userInput)
        _assistantMessages.value = _assistantMessages.value + userMsg

        viewModelScope.launch {
            val intent = VnCommandEngine.parseCommand(userInput, _selectedLanguage.value)
            var actionDescription: String? = null
            var extraInfo = ""

            when (intent) {
                is VnAssistantIntent.PlayWelcomeGreeting -> {
                    actionDescription = "PLAY_GREETING"
                    playWelcomeVoice()
                }
                is VnAssistantIntent.NavigateTo -> {
                    actionDescription = "NAVIGATE_${intent.tab.name}"
                    navigateTo(intent.tab)
                }
                is VnAssistantIntent.CreateNote -> {
                    actionDescription = "CREATE_NOTE"
                    val id = repository.saveNote(
                        NoteEntity(
                            title = intent.title,
                            content = intent.content,
                            category = intent.category,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    extraInfo = "ID #$id"
                }
                is VnAssistantIntent.FindNotes -> {
                    actionDescription = "SEARCH_NOTES"
                    setNoteSearchQuery(intent.query)
                    navigateTo(NavTab.NOTES)
                }
                is VnAssistantIntent.CreateHabit -> {
                    actionDescription = "CREATE_HABIT"
                    repository.saveHabit(
                        HabitEntity(
                            name = intent.name,
                            category = intent.category
                        )
                    )
                }
                is VnAssistantIntent.CompleteHabit -> {
                    actionDescription = "COMPLETE_HABIT"
                    // Find habit matching name
                    val allH = repository.allHabits.first()
                    val target = allH.find { it.name.contains(intent.habitName, ignoreCase = true) } ?: allH.firstOrNull()
                    if (target != null) {
                        repository.setHabitCompletion(target.id, DateUtils.getTodayIso(), true)
                    }
                }
                is VnAssistantIntent.StartFocus -> {
                    actionDescription = "START_FOCUS"
                    setTimerPreset(TimerSessionType.CUSTOM, intent.minutes)
                    startTimer()
                    navigateTo(NavTab.FOCUS)
                }
                is VnAssistantIntent.PauseFocus -> {
                    actionDescription = "PAUSE_FOCUS"
                    pauseTimer()
                }
                is VnAssistantIntent.ResumeFocus -> {
                    actionDescription = "RESUME_FOCUS"
                    resumeTimer()
                }
                is VnAssistantIntent.ResetFocus -> {
                    actionDescription = "RESET_FOCUS"
                    resetTimer()
                }
                is VnAssistantIntent.CreateEvent -> {
                    actionDescription = "CREATE_EVENT"
                    repository.saveEvent(
                        CalendarEventEntity(
                            title = intent.title,
                            date = intent.dateIso,
                            startTime = intent.startTime
                        )
                    )
                }
                is VnAssistantIntent.QueryProgress -> {
                    actionDescription = "QUERY_PROGRESS"
                    val summary = repository.getProductivitySummary().first()
                    extraInfo = "${summary.habitsCompletedToday}/${summary.habitsCount} habits done, ${summary.totalFocusMinutes}m focused"
                }
                is VnAssistantIntent.ChangeTheme -> {
                    actionDescription = "CHANGE_THEME"
                    if (intent.themeName.contains("light", ignoreCase = true)) {
                        setTheme(AppThemeMode.LIGHT_HORIZON)
                    } else if (intent.themeName.contains("neon", ignoreCase = true)) {
                        setTheme(AppThemeMode.CYBER_NEON)
                    } else {
                        setTheme(AppThemeMode.MIDNIGHT_AURORA)
                    }
                }
                is VnAssistantIntent.ChangeLanguage -> {
                    actionDescription = "CHANGE_LANGUAGE"
                    setLanguage(intent.langCode)
                }
                is VnAssistantIntent.GeneralQuery -> {
                    actionDescription = "GREETING"
                }
                is VnAssistantIntent.Unknown -> {
                    actionDescription = "UNKNOWN_COMMAND"
                }
            }

            val replyText = VnCommandEngine.getResponseText(intent, _selectedLanguage.value, extraInfo)
            val assistantReply = AssistantMessage(
                sender = MessageSender.ASSISTANT,
                text = replyText,
                executedAction = actionDescription
            )
            _assistantMessages.value = _assistantMessages.value + assistantReply

            if (_ttsRepliesEnabled.value && intent !is VnAssistantIntent.PlayWelcomeGreeting) {
                val locale = when (_selectedLanguage.value) {
                    "hi" -> Locale("hi", "IN")
                    "es" -> Locale("es", "ES")
                    "fr" -> Locale("fr", "FR")
                    "de" -> Locale("de", "DE")
                    else -> Locale.ENGLISH
                }
                voiceManager.speak(replyText, locale)
            }
        }
    }

    // ==========================================
    // NOTES STATE
    // ==========================================
    private val _noteSearchQuery = MutableStateFlow("")
    val noteSearchQuery: StateFlow<String> = _noteSearchQuery.asStateFlow()

    val notesList: StateFlow<List<NoteEntity>> = _noteSearchQuery
        .flatMapLatest { query -> repository.searchNotes(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _noteDialogState = MutableStateFlow<NoteEntity?>(null)
    val noteDialogState: StateFlow<NoteEntity?> = _noteDialogState.asStateFlow()
    val isNoteDialogOpen = MutableStateFlow(false)

    private val _noteToDelete = MutableStateFlow<NoteEntity?>(null)
    val noteToDelete: StateFlow<NoteEntity?> = _noteToDelete.asStateFlow()

    fun setNoteSearchQuery(query: String) {
        _noteSearchQuery.value = query
    }

    fun openNoteDialog(note: NoteEntity? = null) {
        _noteDialogState.value = note ?: NoteEntity(title = "", content = "")
        isNoteDialogOpen.value = true
    }

    fun closeNoteDialog() {
        isNoteDialogOpen.value = false
        _noteDialogState.value = null
    }

    fun saveNote(title: String, content: String, category: String, isPinned: Boolean, colorTag: String, id: Long = 0) {
        viewModelScope.launch {
            val note = NoteEntity(
                id = id,
                title = title.trim(),
                content = content.trim(),
                category = category,
                isPinned = isPinned,
                colorTag = colorTag,
                updatedAt = System.currentTimeMillis(),
                createdAt = if (id == 0L) System.currentTimeMillis() else _noteDialogState.value?.createdAt ?: System.currentTimeMillis()
            )
            repository.saveNote(note)
            closeNoteDialog()
        }
    }

    fun requestDeleteNote(note: NoteEntity) {
        _noteToDelete.value = note
    }

    fun cancelDeleteNote() {
        _noteToDelete.value = null
    }

    fun confirmDeleteNote() {
        val note = _noteToDelete.value ?: return
        viewModelScope.launch {
            repository.deleteNote(note)
            _noteToDelete.value = null
        }
    }

    // ==========================================
    // HABITS STATE
    // ==========================================
    val habitsList: StateFlow<List<HabitWithProgress>> = repository.getHabitsWithProgress()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isHabitDialogOpen = MutableStateFlow(false)
    private val _habitDialogState = MutableStateFlow<HabitEntity?>(null)
    val habitDialogState: StateFlow<HabitEntity?> = _habitDialogState.asStateFlow()

    private val _habitToDelete = MutableStateFlow<HabitEntity?>(null)
    val habitToDelete: StateFlow<HabitEntity?> = _habitToDelete.asStateFlow()

    fun openHabitDialog(habit: HabitEntity? = null) {
        _habitDialogState.value = habit ?: HabitEntity(name = "")
        isHabitDialogOpen.value = true
    }

    fun closeHabitDialog() {
        isHabitDialogOpen.value = false
        _habitDialogState.value = null
    }

    fun saveHabit(name: String, description: String, category: String, targetDays: Int, colorHex: String, id: Long = 0) {
        viewModelScope.launch {
            val habit = HabitEntity(
                id = id,
                name = name.trim(),
                description = description.trim(),
                category = category,
                targetDaysPerWeek = targetDays,
                colorHex = colorHex,
                createdAt = if (id == 0L) System.currentTimeMillis() else _habitDialogState.value?.createdAt ?: System.currentTimeMillis()
            )
            repository.saveHabit(habit)
            closeHabitDialog()
        }
    }

    fun toggleHabit(habitId: Long, dateIso: String = DateUtils.getTodayIso(), currentStatus: Boolean) {
        viewModelScope.launch {
            repository.setHabitCompletion(habitId, dateIso, !currentStatus)
        }
    }

    fun requestDeleteHabit(habit: HabitEntity) {
        _habitToDelete.value = habit
    }

    fun cancelDeleteHabit() {
        _habitToDelete.value = null
    }

    fun confirmDeleteHabit() {
        val habit = _habitToDelete.value ?: return
        viewModelScope.launch {
            repository.deleteHabit(habit)
            _habitToDelete.value = null
        }
    }

    // ==========================================
    // FOCUS TIMER STATE
    // ==========================================
    private val _timerSessionType = MutableStateFlow(TimerSessionType.FOCUS_25)
    val timerSessionType: StateFlow<TimerSessionType> = _timerSessionType.asStateFlow()

    private val _targetDurationSeconds = MutableStateFlow(25 * 60)
    val targetDurationSeconds: StateFlow<Int> = _targetDurationSeconds.asStateFlow()

    private val _remainingSeconds = MutableStateFlow(25 * 60)
    val remainingSeconds: StateFlow<Int> = _remainingSeconds.asStateFlow()

    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _isTimerPaused = MutableStateFlow(false)
    val isTimerPaused: StateFlow<Boolean> = _isTimerPaused.asStateFlow()

    private val _showSessionCompletedDialog = MutableStateFlow(false)
    val showSessionCompletedDialog: StateFlow<Boolean> = _showSessionCompletedDialog.asStateFlow()

    private var targetEndTimeMillis: Long = 0L
    private var timerJob: Job? = null

    val focusSessionsList: StateFlow<List<FocusSessionEntity>> = repository.allFocusSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalFocusMinutes: StateFlow<Int?> = repository.totalFocusMinutes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun setTimerPreset(sessionType: TimerSessionType, customMinutes: Int? = null) {
        pauseTimer()
        _timerSessionType.value = sessionType
        val durationMins = if (sessionType == TimerSessionType.CUSTOM && customMinutes != null) {
            customMinutes
        } else {
            sessionType.defaultMinutes
        }
        val totalSecs = durationMins * 60
        _targetDurationSeconds.value = totalSecs
        _remainingSeconds.value = totalSecs
        _isTimerRunning.value = false
        _isTimerPaused.value = false
    }

    fun startTimer() {
        if (_isTimerRunning.value) return
        _isTimerRunning.value = true
        _isTimerPaused.value = false
        targetEndTimeMillis = System.currentTimeMillis() + (_remainingSeconds.value * 1000L)

        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_isTimerRunning.value) {
                delay(200)
                val diffMillis = targetEndTimeMillis - System.currentTimeMillis()
                if (diffMillis <= 0) {
                    _remainingSeconds.value = 0
                    _isTimerRunning.value = false
                    _isTimerPaused.value = false
                    onTimerCompleted()
                    break
                } else {
                    _remainingSeconds.value = ((diffMillis + 999) / 1000).toInt()
                }
            }
        }
    }

    fun pauseTimer() {
        if (!_isTimerRunning.value) return
        timerJob?.cancel()
        timerJob = null
        val diffMillis = targetEndTimeMillis - System.currentTimeMillis()
        _remainingSeconds.value = maxOf(0, ((diffMillis + 999) / 1000).toInt())
        _isTimerRunning.value = false
        _isTimerPaused.value = true
    }

    fun resumeTimer() {
        if (_isTimerRunning.value) return
        startTimer()
    }

    fun resetTimer() {
        timerJob?.cancel()
        timerJob = null
        _isTimerRunning.value = false
        _isTimerPaused.value = false
        _remainingSeconds.value = _targetDurationSeconds.value
    }

    private fun onTimerCompleted() {
        triggerHapticFeedback()
        val durationMins = _targetDurationSeconds.value / 60
        val isFocus = _timerSessionType.value != TimerSessionType.SHORT_BREAK && _timerSessionType.value != TimerSessionType.LONG_BREAK
        val typeStr = if (isFocus) "FOCUS" else if (_timerSessionType.value == TimerSessionType.SHORT_BREAK) "SHORT_BREAK" else "LONG_BREAK"
        val label = _timerSessionType.value.displayName

        viewModelScope.launch {
            repository.recordFocusSession(
                durationMinutes = durationMins,
                sessionType = typeStr,
                label = label
            )
            _showSessionCompletedDialog.value = true
        }
    }

    fun dismissSessionCompletedDialog() {
        _showSessionCompletedDialog.value = false
        resetTimer()
    }

    private fun triggerHapticFeedback() {
        try {
            val app = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = app.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 250, 100, 250), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 250, 100, 250), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 250, 100, 250), -1)
                }
            }
        } catch (_: Exception) {
            // Ignore
        }
    }

    // ==========================================
    // CALENDAR & EVENTS STATE
    // ==========================================
    private val _selectedDateIso = MutableStateFlow(DateUtils.getTodayIso())
    val selectedDateIso: StateFlow<String> = _selectedDateIso.asStateFlow()

    private val _viewingMonthCalendar = MutableStateFlow(Calendar.getInstance())
    val viewingMonthCalendar: StateFlow<Calendar> = _viewingMonthCalendar.asStateFlow()

    val allEvents: StateFlow<List<CalendarEventEntity>> = repository.allEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val eventsForSelectedDate: StateFlow<List<CalendarEventEntity>> = _selectedDateIso
        .flatMapLatest { dateIso -> repository.getEventsForDate(dateIso) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val upcomingEvents: StateFlow<List<CalendarEventEntity>> = repository.getUpcomingEvents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isEventDialogOpen = MutableStateFlow(false)
    private val _eventDialogState = MutableStateFlow<CalendarEventEntity?>(null)
    val eventDialogState: StateFlow<CalendarEventEntity?> = _eventDialogState.asStateFlow()

    private val _eventToDelete = MutableStateFlow<CalendarEventEntity?>(null)
    val eventToDelete: StateFlow<CalendarEventEntity?> = _eventToDelete.asStateFlow()

    fun setSelectedDate(dateIso: String) {
        _selectedDateIso.value = dateIso
    }

    fun prevMonth() {
        val cal = Calendar.getInstance().apply { time = _viewingMonthCalendar.value.time }
        cal.add(Calendar.MONTH, -1)
        _viewingMonthCalendar.value = cal
    }

    fun nextMonth() {
        val cal = Calendar.getInstance().apply { time = _viewingMonthCalendar.value.time }
        cal.add(Calendar.MONTH, 1)
        _viewingMonthCalendar.value = cal
    }

    fun goToToday() {
        val today = Calendar.getInstance()
        _viewingMonthCalendar.value = today
        _selectedDateIso.value = DateUtils.getTodayIso()
    }

    fun openEventDialog(event: CalendarEventEntity? = null) {
        _eventDialogState.value = event ?: CalendarEventEntity(
            title = "",
            date = _selectedDateIso.value,
            startTime = "09:00",
            endTime = "10:00"
        )
        isEventDialogOpen.value = true
    }

    fun closeEventDialog() {
        isEventDialogOpen.value = false
        _eventDialogState.value = null
    }

    fun saveEvent(
        title: String,
        description: String,
        dateIso: String,
        startTime: String,
        endTime: String,
        category: String,
        colorHex: String,
        id: Long = 0
    ) {
        viewModelScope.launch {
            val event = CalendarEventEntity(
                id = id,
                title = title.trim(),
                description = description.trim(),
                date = dateIso,
                startTime = startTime.trim(),
                endTime = endTime.trim(),
                category = category,
                colorHex = colorHex
            )
            repository.saveEvent(event)
            closeEventDialog()
        }
    }

    fun requestDeleteEvent(event: CalendarEventEntity) {
        _eventToDelete.value = event
    }

    fun cancelDeleteEvent() {
        _eventToDelete.value = null
    }

    fun confirmDeleteEvent() {
        val event = _eventToDelete.value ?: return
        viewModelScope.launch {
            repository.deleteEvent(event)
            _eventToDelete.value = null
        }
    }

    // ==========================================
    // BACKUP & DATA PURGE
    // ==========================================
    suspend fun exportDataAsJson(): String {
        val root = JSONObject()
        root.put("appName", "VNHIT")
        root.put("version", "1.0")
        root.put("exportedAt", System.currentTimeMillis())

        // Notes
        val notes = repository.allNotes.first()
        val notesArray = JSONArray()
        notes.forEach { n ->
            notesArray.put(
                JSONObject().apply {
                    put("title", n.title)
                    put("content", n.content)
                    put("category", n.category)
                    put("isPinned", n.isPinned)
                    put("updatedAt", n.updatedAt)
                }
            )
        }
        root.put("notes", notesArray)

        // Habits
        val habits = repository.allHabits.first()
        val habitsArray = JSONArray()
        habits.forEach { h ->
            habitsArray.put(
                JSONObject().apply {
                    put("name", h.name)
                    put("category", h.category)
                    put("frequency", h.frequency)
                }
            )
        }
        root.put("habits", habitsArray)

        // Events
        val events = repository.allEvents.first()
        val eventsArray = JSONArray()
        events.forEach { e ->
            eventsArray.put(
                JSONObject().apply {
                    put("title", e.title)
                    put("date", e.date)
                    put("startTime", e.startTime)
                    put("category", e.category)
                }
            )
        }
        root.put("events", eventsArray)

        return root.toString(2)
    }

    fun clearAllData(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            val notes = repository.allNotes.first()
            notes.forEach { repository.deleteNote(it) }

            val habits = repository.allHabits.first()
            habits.forEach { repository.deleteHabit(it) }

            val events = repository.allEvents.first()
            events.forEach { repository.deleteEvent(it) }

            onComplete()
        }
    }

    // ==========================================
    // DASHBOARD PRODUCTIVITY SUMMARY
    // ==========================================
    val productivitySummary: StateFlow<ProductivitySummary> = repository.getProductivitySummary()
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            ProductivitySummary(0, 0, 0, 0f, 0, 0, 0)
        )

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
        audioPlayer.stop()
    }
}
