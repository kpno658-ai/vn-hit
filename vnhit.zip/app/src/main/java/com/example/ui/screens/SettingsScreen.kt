package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Coffee
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.VnhitViewModel
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.SectionHeader
import com.example.ui.components.VnhitCard
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.VnhitBackground
import com.example.ui.theme.VnhitBorder
import com.example.ui.theme.VnhitCyan
import com.example.ui.theme.VnhitError
import com.example.ui.theme.VnhitOrange
import com.example.ui.theme.VnhitPink
import com.example.ui.theme.VnhitSuccess
import com.example.ui.theme.VnhitSurface
import com.example.ui.theme.VnhitSurfaceElevated
import com.example.ui.theme.VnhitSurfaceVariant
import com.example.ui.theme.VnhitTextMuted
import com.example.ui.theme.VnhitTextPrimary
import com.example.ui.theme.VnhitTextSecondary
import com.example.ui.theme.VnhitViolet
import com.example.ui.theme.VnhitWarning
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val currentTheme by viewModel.selectedTheme.collectAsState()
    val currentLang by viewModel.selectedLanguage.collectAsState()
    val autoDetectLang by viewModel.autoDetectLanguage.collectAsState()
    val voiceEnabled by viewModel.voiceInputEnabled.collectAsState()
    val ttsRepliesEnabled by viewModel.ttsRepliesEnabled.collectAsState()
    val reducedMotion by viewModel.reducedMotion.collectAsState()
    val refreshRate by viewModel.refreshRate.collectAsState()
    val quietHours by viewModel.quietHoursEnabled.collectAsState()

    val modelInstalled by viewModel.onDeviceModelInstalled.collectAsState()
    val isModelDownloading by viewModel.isModelDownloading.collectAsState()
    val downloadProgress by viewModel.modelDownloadProgress.collectAsState()

    val summary by viewModel.productivitySummary.collectAsState()

    var showClearDataDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf<String?>(null) }
    var showCoffeeDialog by remember { mutableStateOf(false) }

    val languages = listOf(
        Pair("en", "English"),
        Pair("hi", "हिंदी (Hindi)"),
        Pair("hinglish", "Hinglish"),
        Pair("es", "Español"),
        Pair("fr", "Français"),
        Pair("de", "Deutsch"),
        Pair("bn", "বাংলা (Bengali)"),
        Pair("ta", "தமிழ் (Tamil)")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VnhitBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Screen Title
        item {
            Column {
                Text(
                    text = "System Settings",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = VnhitTextPrimary
                    )
                )
                Text(
                    text = "Manage preferences, themes, language, and on-device privacy",
                    style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                )
            }
        }

        // 1. Language & Multilingual Assistant
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = VnhitCyan, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LANGUAGE & LOCALIZATION",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitCyan,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Assistant & Display Language", color = VnhitTextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(languages) { (code, name) ->
                            val isSelected = currentLang == code
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) VnhitCyan else VnhitSurfaceElevated,
                                modifier = Modifier
                                    .border(1.dp, if (isSelected) VnhitCyan else VnhitBorder, RoundedCornerShape(14.dp))
                                    .clickable { viewModel.setLanguage(code) }
                                    .testTag("lang_select_$code")
                            ) {
                                Text(
                                    text = name,
                                    color = if (isSelected) Color(0xFF00363F) else VnhitTextSecondary,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SettingsToggleRow(
                        title = "Automatic Language Detection",
                        subtitle = "Detect input language when switching between English and Hindi",
                        checked = autoDetectLang,
                        onCheckedChange = { viewModel.setAutoDetectLanguage(it) },
                        testTag = "toggle_auto_detect_lang"
                    )
                }
            }
        }

        // 2. Visual Themes
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = VnhitViolet, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "APPEARANCE & THEME",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitViolet,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(AppThemeMode.entries) { theme ->
                            val isSelected = currentTheme == theme
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) VnhitViolet else VnhitSurfaceElevated,
                                modifier = Modifier
                                    .border(1.dp, if (isSelected) VnhitViolet else VnhitBorder, RoundedCornerShape(14.dp))
                                    .clickable { viewModel.setTheme(theme) }
                                    .testTag("theme_select_${theme.name.lowercase()}")
                            ) {
                                Text(
                                    text = theme.displayName,
                                    color = if (isSelected) Color.White else VnhitTextSecondary,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Voice & Audio Preferences
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = VnhitPink, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VOICE & SPEECH CONTROLS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitPink,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SettingsToggleRow(
                        title = "Voice Input Support",
                        subtitle = "Enable speech-to-text button in VN Assistant",
                        checked = voiceEnabled,
                        onCheckedChange = { viewModel.setVoiceInputEnabled(it) },
                        testTag = "toggle_voice_input"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    SettingsToggleRow(
                        title = "Spoken Responses (TTS)",
                        subtitle = "Play spoken confirmations via Android Text-to-Speech",
                        checked = ttsRepliesEnabled,
                        onCheckedChange = { viewModel.setTtsRepliesEnabled(it) },
                        testTag = "toggle_tts_replies_setting"
                    )
                }
            }
        }

        // 4. Modest Device Optimizations & Display
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = VnhitOrange, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PERFORMANCE & BATTERY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitOrange,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SettingsToggleRow(
                        title = "Low-End Mode / Reduced Motion",
                        subtitle = "Disables glowing pulse animations to maximize battery life on modest phones",
                        checked = reducedMotion,
                        onCheckedChange = { viewModel.setReducedMotion(it) },
                        testTag = "toggle_reduced_motion"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Target Refresh Rate", color = VnhitTextPrimary, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(6.dp))

                    val refreshRates = listOf("60Hz (Standard)", "90Hz (Smooth)", "120Hz (Ultra)")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(refreshRates) { rate ->
                            val isSelected = refreshRate == rate
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) VnhitOrange else VnhitSurfaceElevated,
                                modifier = Modifier
                                    .border(1.dp, if (isSelected) VnhitOrange else VnhitBorder, RoundedCornerShape(12.dp))
                                    .clickable { viewModel.setRefreshRate(rate) }
                            ) {
                                Text(
                                    text = rate,
                                    color = if (isSelected) Color(0xFF381A00) else VnhitTextSecondary,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. On-Device AI Model Management Card
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = VnhitCyan, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ON-DEVICE AI ENGINE (LOCAL)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitCyan,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Primary Architecture: Deterministic Natural Language Engine",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = VnhitTextPrimary)
                    )
                    Text(
                        text = "Active engine requires 0 MB downloads, consumes near-zero RAM, operates 100% offline, and handles multilingual productivity commands deterministically without battery drain.",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = VnhitSurfaceElevated,
                        modifier = Modifier.fillMaxWidth().border(1.dp, VnhitBorder, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Candidate LLM: Qwen2.5-0.5B-Instruct",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = VnhitTextPrimary)
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (modelInstalled) VnhitSuccess.copy(alpha = 0.2f) else VnhitBorder
                                ) {
                                    Text(
                                        text = if (modelInstalled) "VERIFIED" else "STANDBY",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (modelInstalled) VnhitSuccess else VnhitTextMuted,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Quantized footprint: ~380MB. Feasibility evaluation: Native deterministic parser is active to protect modest device RAM.",
                                style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextMuted)
                            )

                            if (isModelDownloading) {
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { downloadProgress },
                                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                    color = VnhitCyan,
                                    trackColor = VnhitSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row {
                                if (!modelInstalled) {
                                    Button(
                                        onClick = { viewModel.startModelInstallation() },
                                        enabled = !isModelDownloading,
                                        colors = ButtonDefaults.buttonColors(containerColor = VnhitCyan, contentColor = Color(0xFF00363F)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("init_model_button")
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isModelDownloading) "Verifying Local Cache..." else "Initialize Local Package", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = { viewModel.removeModel() },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.testTag("remove_model_button")
                                    ) {
                                        Text("Reset Model Package", color = VnhitTextSecondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Local Storage & Backup
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = VnhitSuccess, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LOCAL STORAGE & PRIVACY",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = VnhitSuccess,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "All notes, habits, focus history, and calendar events are stored on this device in SQLite. No cloud account or external database is required.",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val json = viewModel.exportDataAsJson()
                                    exportedJsonText = json
                                    clipboardManager.setText(AnnotatedString(json))
                                    Toast.makeText(context, "Exported JSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = VnhitSurfaceElevated, contentColor = VnhitCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).border(1.dp, VnhitCyan, RoundedCornerShape(8.dp)).testTag("export_data_button")
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export JSON")
                        }

                        Button(
                            onClick = { showClearDataDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = VnhitSurfaceElevated, contentColor = VnhitError),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f).border(1.dp, VnhitError.copy(alpha = 0.5f), RoundedCornerShape(8.dp)).testTag("clear_data_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Reset Data")
                        }
                    }
                }
            }
        }

        // 7. Voluntary Support ("Buy Me a Coffee")
        item {
            VnhitCard(
                borderColor = VnhitWarning.copy(alpha = 0.5f),
                backgroundColor = VnhitSurface,
                modifier = Modifier.fillMaxWidth().clickable { showCoffeeDialog = true }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(VnhitWarning.copy(alpha = 0.15f))
                            .border(1.dp, VnhitWarning, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Coffee, contentDescription = null, tint = VnhitWarning, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Support VNHIT (Optional)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = VnhitTextPrimary)
                        )
                        Text(
                            text = "VNHIT is 100% free with no ads. Voluntary support keeps development independent.",
                            style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                        )
                    }
                }
            }
        }

        // 8. About VNHIT
        item {
            VnhitCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ABOUT VNHIT v1.0",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = VnhitCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "VNHIT v1.0 — Professional Android Productivity Suite",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = VnhitTextPrimary)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "\"Small steps. Quiet rewards. Real progress.\"",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = VnhitViolet
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Built strictly in native Kotlin & Jetpack Compose with Room SQLite. Zero subscriptions, zero mandatory cloud services, and zero user telemetry.",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextMuted)
                    )
                }
            }
        }
    }

    // Clear Data Confirmation Dialog
    if (showClearDataDialog) {
        DeleteConfirmationDialog(
            title = "Reset All Local Data?",
            message = "This will permanently remove all locally saved notes, habits, focus logs, and events from SQLite. This action cannot be undone.",
            onConfirm = {
                viewModel.clearAllData {
                    showClearDataDialog = false
                    Toast.makeText(context, "All local data has been reset.", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = { showClearDataDialog = false }
        )
    }

    // Exported JSON Dialog
    if (exportedJsonText != null) {
        AlertDialog(
            onDismissRequest = { exportedJsonText = null },
            title = { Text("Backup Data Exported", fontWeight = FontWeight.Bold, color = VnhitTextPrimary) },
            text = {
                Column {
                    Text("Your data has been formatted as JSON and copied to your clipboard.", color = VnhitTextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = exportedJsonText!!.take(300) + "...",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = VnhitCyan
                    )
                }
            },
            containerColor = VnhitSurface,
            confirmButton = {
                Button(
                    onClick = { exportedJsonText = null },
                    colors = ButtonDefaults.buttonColors(containerColor = VnhitCyan, contentColor = Color(0xFF00363F)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Done", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Buy Me a Coffee Information Dialog
    if (showCoffeeDialog) {
        AlertDialog(
            onDismissRequest = { showCoffeeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Coffee, contentDescription = null, tint = VnhitWarning)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Voluntary Donation", fontWeight = FontWeight.Bold, color = VnhitTextPrimary)
                }
            },
            text = {
                Text(
                    text = "VNHIT is and will always remain completely free with zero ads, subscriptions, or paywalled features. Optional voluntary donation links are completely separate from functionality.\n\nThank you for using VNHIT!",
                    color = VnhitTextSecondary
                )
            },
            containerColor = VnhitSurface,
            confirmButton = {
                Button(
                    onClick = { showCoffeeDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = VnhitWarning, contentColor = Color(0xFF381A00)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Got It", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = VnhitTextPrimary, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
            Text(text = subtitle, color = VnhitTextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = VnhitCyan,
                checkedTrackColor = Color(0xFF004E5B)
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}
