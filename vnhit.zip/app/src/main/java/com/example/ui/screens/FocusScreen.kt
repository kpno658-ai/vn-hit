package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.FocusSessionEntity
import com.example.ui.TimerSessionType
import com.example.ui.VnhitViewModel
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SectionHeader
import com.example.ui.components.VnhitCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FocusScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val remainingSeconds by viewModel.remainingSeconds.collectAsState()
    val targetDurationSeconds by viewModel.targetDurationSeconds.collectAsState()
    val isRunning by viewModel.isTimerRunning.collectAsState()
    val isPaused by viewModel.isTimerPaused.collectAsState()
    val currentPreset by viewModel.timerSessionType.collectAsState()
    val showCompleteDialog by viewModel.showSessionCompletedDialog.collectAsState()
    val totalFocusMins by viewModel.totalFocusMinutes.collectAsState()
    val sessionsList by viewModel.focusSessionsList.collectAsState()

    var showCustomDialog by remember { mutableStateOf(false) }

    val progress = if (targetDurationSeconds > 0) {
        remainingSeconds.toFloat() / targetDurationSeconds.toFloat()
    } else 0f

    val animatedProgress by animateFloatAsState(targetValue = progress, label = "timerProgress")

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val timeFormatted = String.format(Locale.US, "%02d:%02d", minutes, seconds)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(VnhitBackground)
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Screen Header
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "EPOCH TIMESTAMP ENGINE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = VnhitCyan,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        fontSize = 10.sp
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Pomodoro Focus Timer",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
        }

        // Radial Timer Display
        item {
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(VnhitSurface)
                    .border(4.dp, VnhitCyan.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Canvas Dial
                Canvas(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    val strokeWidth = 10.dp.toPx()
                    // Background track
                    drawCircle(
                        color = Color(0x14FFFFFF),
                        style = Stroke(width = strokeWidth)
                    )
                    // Progress arc with Aurora Sweep Gradient
                    drawArc(
                        brush = androidx.compose.ui.graphics.Brush.sweepGradient(
                            listOf(VnhitCyan, VnhitPink, VnhitViolet, VnhitCyan)
                        ),
                        startAngle = -90f,
                        sweepAngle = 360f * animatedProgress,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                // Inner Time Readout
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = timeFormatted,
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = Color.White,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.testTag("timer_countdown_text")
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = when {
                            isRunning -> "FOCUSING..."
                            isPaused -> "PAUSED"
                            else -> "READY"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = when {
                                isRunning -> VnhitPink
                                isPaused -> VnhitWarning
                                else -> VnhitCyan
                            },
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            fontSize = 10.sp
                        ),
                        modifier = Modifier.testTag("focus_status_badge")
                    )
                }
            }
        }

        // Session Selection Preset Buttons
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val durations = listOf(
                    Pair("15 Min", 15),
                    Pair("25 Min", 25),
                    Pair("45 Min", 45),
                    Pair("60 Min", 60)
                )

                durations.forEach { (label, mins) ->
                    val isSelected = targetDurationSeconds == mins * 60
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) VnhitCyan else VnhitSurface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) VnhitCyan else VnhitBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                viewModel.setTimerPreset(TimerSessionType.CUSTOM, mins)
                            }
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) com.example.ui.theme.Slate950 else com.example.ui.theme.Slate400,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            ),
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Play/Pause & Reset Controls
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Main Gradient Play/Pause Button
                Button(
                    onClick = {
                        if (isRunning) {
                            viewModel.pauseTimer()
                        } else {
                            viewModel.startTimer()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        contentColor = com.example.ui.theme.Slate950
                    ),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .width(180.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            androidx.compose.ui.graphics.Brush.horizontalGradient(
                                listOf(VnhitCyan, VnhitBlue, VnhitViolet)
                            )
                        )
                        .testTag("toggle_timer_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isRunning) "Pause" else "Start",
                            tint = com.example.ui.theme.Slate950,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isRunning) "Pause" else if (isPaused) "Resume" else "Start Session",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = com.example.ui.theme.Slate950
                            )
                        )
                    }
                }

                // Reset Button
                IconButton(
                    onClick = { viewModel.resetTimer() },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(VnhitSurface)
                        .border(1.dp, VnhitBorder, RoundedCornerShape(18.dp))
                        .testTag("reset_timer_button")
                ) {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Reset Timer",
                        tint = com.example.ui.theme.Slate400,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Focus Analytics Card
        item {
            VnhitCard(
                backgroundColor = VnhitSurface,
                borderColor = VnhitBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${totalFocusMins ?: 0}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = VnhitCyan
                            )
                        )
                        Text(
                            text = "Total Focus Mins",
                            style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextSecondary)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(40.dp)
                            .background(VnhitBorder)
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${sessionsList.size}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = VnhitViolet
                            )
                        )
                        Text(
                            text = "Sessions Logged",
                            style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextSecondary)
                        )
                    }
                }
            }
        }

        // Session History Header
        item {
            SectionHeader(
                title = "Focus History",
                subtitle = "Saved locally to Room database"
            )
        }

        if (sessionsList.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.HourglassBottom,
                    title = "No completed sessions yet",
                    description = "Complete your first 25-minute focus session to log history and unlock productivity momentum."
                )
            }
        } else {
            items(sessionsList.take(10), key = { it.id }) { session ->
                FocusHistoryCard(session)
            }
        }
    }

    // Session Completed Dialog
    if (showCompleteDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissSessionCompletedDialog() },
            title = {
                Text(
                    text = "Session Completed! 🎉",
                    fontWeight = FontWeight.Bold,
                    color = VnhitTextPrimary
                )
            },
            text = {
                Text(
                    text = "Great job! Your focus time has been recorded. Would you like to take a 5-minute break now?",
                    color = VnhitTextSecondary
                )
            },
            containerColor = VnhitSurface,
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.dismissSessionCompletedDialog()
                        viewModel.setTimerPreset(TimerSessionType.SHORT_BREAK)
                        viewModel.startTimer()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VnhitViolet),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("start_break_button")
                ) {
                    Text("Start 5m Break", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.dismissSessionCompletedDialog() },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("dismiss_session_dialog")
                ) {
                    Text("Done", color = VnhitTextSecondary)
                }
            }
        )
    }

    // Custom Duration Dialog
    if (showCustomDialog) {
        var customMinsText by remember { mutableStateOf("30") }
        AlertDialog(
            onDismissRequest = { showCustomDialog = false },
            title = {
                Text("Custom Duration", fontWeight = FontWeight.Bold, color = VnhitTextPrimary)
            },
            text = {
                Column {
                    Text("Enter duration in minutes (1 - 180):", color = VnhitTextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customMinsText,
                        onValueChange = { customMinsText = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VnhitCyan,
                            unfocusedBorderColor = VnhitBorder,
                            focusedTextColor = VnhitTextPrimary,
                            unfocusedTextColor = VnhitTextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("custom_minutes_input")
                    )
                }
            },
            containerColor = VnhitSurface,
            confirmButton = {
                Button(
                    onClick = {
                        val mins = customMinsText.toIntOrNull()?.coerceIn(1, 180) ?: 25
                        viewModel.setTimerPreset(TimerSessionType.CUSTOM, mins)
                        showCustomDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VnhitCyan, contentColor = Color(0xFF00363F)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("save_custom_duration_button")
                ) {
                    Text("Set Timer", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showCustomDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Cancel", color = VnhitTextSecondary)
                }
            }
        )
    }
}

@Composable
fun FocusHistoryCard(session: FocusSessionEntity) {
    val dateStr = remember(session.completedAt) {
        SimpleDateFormat("MMM d, yyyy · hh:mm a", Locale.US).format(Date(session.completedAt))
    }

    VnhitCard(
        backgroundColor = VnhitSurface,
        borderColor = VnhitBorder,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("focus_history_${session.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        if (session.sessionType == "FOCUS") VnhitCyan.copy(alpha = 0.15f) else VnhitViolet.copy(alpha = 0.15f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Timer,
                    contentDescription = null,
                    tint = if (session.sessionType == "FOCUS") VnhitCyan else VnhitViolet,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.label,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = VnhitTextPrimary
                    )
                )
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextMuted)
                )
            }

            Text(
                text = "+${session.durationMinutes}m",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (session.sessionType == "FOCUS") VnhitCyan else VnhitViolet
                )
            )
        }
    }
}
