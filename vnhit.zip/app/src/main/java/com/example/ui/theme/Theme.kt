package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val displayName: String) {
    MIDNIGHT_AURORA("Midnight Aurora"),
    DEEP_OBSIDIAN("Deep Obsidian"),
    CYBER_NEON("Cyber Neon"),
    LIGHT_HORIZON("Light Horizon")
}

private val MidnightAuroraScheme = darkColorScheme(
    primary = VnhitCyan,
    onPrimary = Slate950,
    primaryContainer = Color(0xFF003840),
    onPrimaryContainer = Color(0xFFB3FBFF),
    secondary = VnhitPink,
    onSecondary = Color(0xFF3E001B),
    secondaryContainer = Color(0xFF670030),
    onSecondaryContainer = Color(0xFFFFD9E4),
    tertiary = VnhitViolet,
    onTertiary = Color(0xFF3B0068),
    background = VnhitBackground,
    onBackground = Slate100,
    surface = VnhitSurface,
    onSurface = Slate100,
    surfaceVariant = VnhitSurfaceVariant,
    onSurfaceVariant = Slate400,
    outline = VnhitBorder,
    outlineVariant = VnhitBorderSubtle,
    error = VnhitError,
    onError = Color.White
)

private val DeepObsidianScheme = darkColorScheme(
    primary = VnhitCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF002730),
    onPrimaryContainer = Color(0xFFB3FBFF),
    secondary = VnhitViolet,
    onSecondary = Color.White,
    tertiary = VnhitPink,
    background = VnhitBackgroundObsidian,
    onBackground = Slate100,
    surface = Color(0xFF070B17),
    onSurface = Slate100,
    surfaceVariant = Color(0xFF0E1424),
    onSurfaceVariant = Slate400,
    outline = Color(0x1AFFFFFF),
    outlineVariant = Color(0x0FFFFFFF),
    error = VnhitError
)

private val CyberNeonScheme = darkColorScheme(
    primary = VnhitCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF004552),
    onPrimaryContainer = Color(0xFFE0FCFF),
    secondary = VnhitLaser,
    onSecondary = Color.White,
    tertiary = VnhitViolet,
    background = Color(0xFF03050C),
    onBackground = Color.White,
    surface = Color(0xFF0B1021),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF131B34),
    onSurfaceVariant = Slate300,
    outline = Color(0x2E00F0FF),
    outlineVariant = Color(0x1A00F0FF),
    error = VnhitLaser
)

private val LightHorizonScheme = lightColorScheme(
    primary = Color(0xFF0284C7),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF9333EA),
    onSecondary = Color.White,
    tertiary = Color(0xFFDB2777),
    background = VnhitLightBackground,
    onBackground = VnhitLightTextPrimary,
    surface = VnhitLightSurface,
    onSurface = VnhitLightTextPrimary,
    surfaceVariant = VnhitLightSurfaceVariant,
    onSurfaceVariant = VnhitLightTextSecondary,
    outline = VnhitLightBorder,
    outlineVariant = Color(0xFFCBD5E1),
    error = VnhitError
)

@Composable
fun VnhitTheme(
    themeMode: AppThemeMode = AppThemeMode.MIDNIGHT_AURORA,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.MIDNIGHT_AURORA -> MidnightAuroraScheme
        AppThemeMode.DEEP_OBSIDIAN -> DeepObsidianScheme
        AppThemeMode.CYBER_NEON -> CyberNeonScheme
        AppThemeMode.LIGHT_HORIZON -> LightHorizonScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    VnhitTheme(themeMode = AppThemeMode.MIDNIGHT_AURORA, content = content)
}
