package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CalendarEventEntity
import com.example.ui.VnhitViewModel
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SectionHeader
import com.example.ui.components.VnhitCard
import com.example.ui.theme.*
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDateIso by viewModel.selectedDateIso.collectAsState()
    val viewingMonthCal by viewModel.viewingMonthCalendar.collectAsState()
    val eventsForSelectedDate by viewModel.eventsForSelectedDate.collectAsState()
    val allEvents by viewModel.allEvents.collectAsState()
    val upcomingEvents by viewModel.upcomingEvents.collectAsState()
    val isDialogOpen by viewModel.isEventDialogOpen.collectAsState()
    val activeDialogEvent by viewModel.eventDialogState.collectAsState()
    val eventToDelete by viewModel.eventToDelete.collectAsState()

    // Map of dates with events for dots
    val datesWithEvents = remember(allEvents) {
        allEvents.map { it.date }.toSet()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = VnhitBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openEventDialog(null) },
                containerColor = VnhitCyan,
                contentColor = Color(0xFF00363F),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_event_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Event")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Column {
                    Text(
                        text = "Calendar & Events",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = VnhitTextPrimary
                        )
                    )
                    Text(
                        text = "Local in-app schedule & event timeline",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                    )
                }
            }

            // Month Navigation Card
            item {
                VnhitCard(
                    backgroundColor = VnhitSurface,
                    borderColor = VnhitBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Month Selector Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = { viewModel.prevMonth() },
                                modifier = Modifier.testTag("calendar_prev_month")
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Previous Month",
                                    tint = VnhitTextPrimary
                                )
                            }

                            Text(
                                text = DateUtils.formatMonthYear(viewingMonthCal),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = VnhitTextPrimary
                                )
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = VnhitSurfaceElevated,
                                    modifier = Modifier
                                        .clickable { viewModel.goToToday() }
                                        .border(1.dp, VnhitBorder, RoundedCornerShape(12.dp))
                                        .testTag("calendar_today_button")
                                ) {
                                    Text(
                                        text = "Today",
                                        color = VnhitCyan,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = { viewModel.nextMonth() },
                                    modifier = Modifier.testTag("calendar_next_month")
                                ) {
                                    Icon(
                                        Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = "Next Month",
                                        tint = VnhitTextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Days of week header
                        val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            daysOfWeek.forEach { day ->
                                Text(
                                    text = day,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = VnhitTextMuted,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.width(36.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Calendar Grid Days
                        MonthGrid(
                            viewingCal = viewingMonthCal,
                            selectedDateIso = selectedDateIso,
                            datesWithEvents = datesWithEvents,
                            onDateSelected = { dateIso -> viewModel.setSelectedDate(dateIso) }
                        )
                    }
                }
            }

            // Selected Date Events Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = DateUtils.formatForDisplay(selectedDateIso),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = VnhitCyan
                            )
                        )
                        Text(
                            text = "${eventsForSelectedDate.size} in-app events scheduled",
                            style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                        )
                    }
                }
            }

            // Events List for Selected Date
            if (eventsForSelectedDate.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.Event,
                        title = "No events on this day",
                        description = "Schedule a task, deadline, meeting, or reminder for this date.",
                        actionButtonText = "+ Add Event for This Date",
                        onActionClick = { viewModel.openEventDialog(null) }
                    )
                }
            } else {
                items(eventsForSelectedDate, key = { it.id }) { event ->
                    EventCardItem(
                        event = event,
                        onEdit = { viewModel.openEventDialog(event) },
                        onDelete = { viewModel.requestDeleteEvent(event) }
                    )
                }
            }

            // Upcoming Events Timeline
            if (upcomingEvents.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    SectionHeader(
                        title = "Upcoming Events",
                        subtitle = "Future schedule timeline"
                    )
                }

                items(upcomingEvents.take(5), key = { "upcoming_${it.id}" }) { event ->
                    EventCardItem(
                        event = event,
                        showDate = true,
                        onEdit = { viewModel.openEventDialog(event) },
                        onDelete = { viewModel.requestDeleteEvent(event) }
                    )
                }
            }
        }
    }

    // Add / Edit Event Dialog
    if (isDialogOpen && activeDialogEvent != null) {
        EventEditDialog(
            initialEvent = activeDialogEvent!!,
            onDismiss = { viewModel.closeEventDialog() },
            onSave = { title, desc, date, start, end, category, color ->
                viewModel.saveEvent(
                    title = title,
                    description = desc,
                    dateIso = date,
                    startTime = start,
                    endTime = end,
                    category = category,
                    colorHex = color,
                    id = activeDialogEvent!!.id
                )
            }
        )
    }

    // Delete Confirmation
    if (eventToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Event?",
            message = "Are you sure you want to delete \"${eventToDelete!!.title}\"?",
            onConfirm = { viewModel.confirmDeleteEvent() },
            onDismiss = { viewModel.cancelDeleteEvent() }
        )
    }
}

@Composable
fun MonthGrid(
    viewingCal: Calendar,
    selectedDateIso: String,
    datesWithEvents: Set<String>,
    onDateSelected: (String) -> Unit
) {
    val cal = Calendar.getInstance().apply {
        time = viewingCal.time
        set(Calendar.DAY_OF_MONTH, 1)
    }

    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    // Java Calendar: Sunday=1, Monday=2 ... Saturday=7
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
    // Convert to Monday=0 .. Sunday=6
    val emptyStartCells = (firstDayOfWeek + 5) % 7

    val todayIso = DateUtils.getTodayIso()
    val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    val totalCells = emptyStartCells + daysInMonth
    val rows = (totalCells + 6) / 7

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (r in 0 until rows) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                for (c in 0 until 7) {
                    val cellIndex = r * 7 + c
                    val dayOfMonth = cellIndex - emptyStartCells + 1

                    if (dayOfMonth in 1..daysInMonth) {
                        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                        val dateIso = isoFormat.format(cal.time)
                        val isSelected = dateIso == selectedDateIso
                        val isToday = dateIso == todayIso
                        val hasEvent = datesWithEvents.contains(dateIso)

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isSelected -> VnhitCyan
                                        isToday -> VnhitSurfaceElevated
                                        else -> Color.Transparent
                                    }
                                )
                                .border(
                                    1.dp,
                                    when {
                                        isSelected -> VnhitCyan
                                        isToday -> VnhitCyan.copy(alpha = 0.6f)
                                        else -> Color.Transparent
                                    },
                                    CircleShape
                                )
                                .clickable { onDateSelected(dateIso) }
                                .testTag("calendar_day_$dateIso"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$dayOfMonth",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color(0xFF00363F) else VnhitTextPrimary
                                    )
                                )
                                if (hasEvent) {
                                    Box(
                                        modifier = Modifier
                                            .size(4.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) Color(0xFF00363F) else VnhitCyan)
                                    )
                                }
                            }
                        }
                    } else {
                        // Empty slot
                        Spacer(modifier = Modifier.size(36.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun EventCardItem(
    event: CalendarEventEntity,
    showDate: Boolean = false,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = VnhitSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, VnhitBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("event_card_${event.id}")
            .clickable(onClick = onEdit)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(72.dp)
                    .background(VnhitPink)
            )
            Column(modifier = Modifier.padding(14.dp).weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category Chip
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = VnhitSurfaceElevated
                ) {
                    Text(
                        text = event.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = VnhitViolet,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // In-App Event badge (fulfills user specification)
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = VnhitCyan.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "In-App Event",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = VnhitCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(28.dp).testTag("edit_event_${event.id}")
                ) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Edit Event",
                        tint = VnhitTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(28.dp).testTag("delete_event_${event.id}")
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete Event",
                        tint = VnhitError,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = event.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = VnhitTextPrimary
                )
            )

            if (event.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = event.description,
                    style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = null,
                    tint = VnhitTextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${DateUtils.formatTimeDisplay(event.startTime)} - ${DateUtils.formatTimeDisplay(event.endTime)}",
                    style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextMuted)
                )
                if (showDate) {
                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = VnhitCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = event.date,
                        style = MaterialTheme.typography.labelSmall.copy(color = VnhitCyan)
                    )
                }
            }
        }
    }
}
}

@Composable
fun EventEditDialog(
    initialEvent: CalendarEventEntity,
    onDismiss: () -> Unit,
    onSave: (title: String, desc: String, date: String, start: String, end: String, category: String, color: String) -> Unit
) {
    var title by remember { mutableStateOf(initialEvent.title) }
    var description by remember { mutableStateOf(initialEvent.description) }
    var date by remember { mutableStateOf(initialEvent.date) }
    var startTime by remember { mutableStateOf(initialEvent.startTime) }
    var endTime by remember { mutableStateOf(initialEvent.endTime) }
    var category by remember { mutableStateOf(initialEvent.category) }
    var colorHex by remember { mutableStateOf(initialEvent.colorHex) }

    var validationError by remember { mutableStateOf<String?>(null) }
    val categories = listOf("Work", "Study", "Personal", "Health", "Deadline")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialEvent.id == 0L) "New Calendar Event" else "Edit Event",
                color = VnhitTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        color = VnhitError,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        validationError = null
                    },
                    placeholder = { Text("Event Title *", color = VnhitTextMuted) },
                    modifier = Modifier.fillMaxWidth().testTag("event_title_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text("Description / Location (optional)", color = VnhitTextMuted) },
                    modifier = Modifier.fillMaxWidth().testTag("event_desc_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)", color = VnhitTextSecondary) },
                    modifier = Modifier.fillMaxWidth().testTag("event_date_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = { startTime = it },
                        label = { Text("Start (HH:mm)", color = VnhitTextSecondary) },
                        modifier = Modifier.weight(1f).testTag("event_start_time_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VnhitCyan,
                            unfocusedBorderColor = VnhitBorder,
                            focusedTextColor = VnhitTextPrimary,
                            unfocusedTextColor = VnhitTextPrimary
                        ),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = { endTime = it },
                        label = { Text("End (HH:mm)", color = VnhitTextSecondary) },
                        modifier = Modifier.weight(1f).testTag("event_end_time_input"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = VnhitCyan,
                            unfocusedBorderColor = VnhitBorder,
                            focusedTextColor = VnhitTextPrimary,
                            unfocusedTextColor = VnhitTextPrimary
                        ),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Category", color = VnhitTextSecondary, style = MaterialTheme.typography.labelSmall)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        val isSelected = category == cat
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) VnhitViolet else VnhitSurfaceVariant,
                            modifier = Modifier
                                .border(1.dp, if (isSelected) VnhitViolet else VnhitBorder, RoundedCornerShape(14.dp))
                                .clickable { category = cat }
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) Color.White else VnhitTextSecondary,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        },
        containerColor = VnhitSurface,
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        validationError = "Title cannot be empty."
                    } else if (DateUtils.parseIso(date) == null) {
                        validationError = "Invalid date format. Use YYYY-MM-DD."
                    } else {
                        onSave(title, description, date, startTime, endTime, category, colorHex)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = VnhitCyan,
                    contentColor = Color(0xFF00363F)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("save_event_button")
            ) {
                Text("Save Event", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("cancel_event_button")
            ) {
                Text("Cancel", color = VnhitTextSecondary)
            }
        }
    )
}
