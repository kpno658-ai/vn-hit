package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.assistant.AssistantMessage
import com.example.assistant.MessageSender
import com.example.assistant.VoiceState
import com.example.ui.VnhitViewModel
import com.example.ui.components.VnhitCard
import com.example.ui.theme.VnhitBackground
import com.example.ui.theme.VnhitBorder
import com.example.ui.theme.VnhitCyan
import com.example.ui.theme.VnhitCyanGlow
import com.example.ui.theme.VnhitPink
import com.example.ui.theme.VnhitPinkGlow
import com.example.ui.theme.VnhitSurface
import com.example.ui.theme.VnhitSurfaceElevated
import com.example.ui.theme.VnhitSurfaceVariant
import com.example.ui.theme.VnhitTextMuted
import com.example.ui.theme.VnhitTextPrimary
import com.example.ui.theme.VnhitTextSecondary
import com.example.ui.theme.VnhitViolet
import com.example.ui.theme.VnhitVioletGlow
import com.example.ui.theme.VnhitWarning

@Composable
fun AssistantScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val messages by viewModel.assistantMessages.collectAsState()
    val voiceState by viewModel.voiceManager.voiceState.collectAsState()
    val ttsRepliesEnabled by viewModel.ttsRepliesEnabled.collectAsState()
    val reducedMotion by viewModel.reducedMotion.collectAsState()

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Permission launcher for voice recognition
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.voiceManager.startListening { spokenText ->
                inputText = spokenText
                viewModel.executeAssistantCommand(spokenText)
                inputText = ""
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = VnhitBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Header Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "VN Assistant",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = VnhitTextPrimary
                        )
                    )
                    Text(
                        text = "Virtual Natural Language Assistant · 100% Offline",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitCyan)
                    )
                }

                // Voice Greeting Button (Plays uploaded intro audio)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = VnhitViolet.copy(alpha = 0.2f),
                    modifier = Modifier
                        .border(1.dp, VnhitViolet, RoundedCornerShape(12.dp))
                        .clickable { viewModel.playWelcomeVoice() }
                        .testTag("play_welcome_voice_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play Intro",
                            tint = VnhitViolet,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Meet VN",
                            color = VnhitViolet,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Animated VN Assistant Orb
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center
            ) {
                VnAssistantOrb(
                    voiceState = voiceState,
                    reducedMotion = reducedMotion,
                    onClick = {
                        if (voiceState == VoiceState.LISTENING) {
                            viewModel.voiceManager.stopListening()
                        } else {
                            val hasPermission = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPermission) {
                                viewModel.voiceManager.startListening { spoken ->
                                    viewModel.executeAssistantCommand(spoken)
                                }
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                )
            }

            // Quick Prompt Chips
            val quickPrompts = listOf(
                "Start 25m Focus",
                "Create a Note",
                "Reading habit complete",
                "Show my progress",
                "Play voice greeting",
                "Switch to dark theme"
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickPrompts) { prompt ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = VnhitSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, VnhitBorder, RoundedCornerShape(16.dp))
                            .clickable {
                                viewModel.executeAssistantCommand(prompt)
                            }
                            .testTag("quick_prompt_${prompt.lowercase().replace(" ", "_")}")
                    ) {
                        Text(
                            text = prompt,
                            color = VnhitTextSecondary,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Transcript / Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    AssistantMessageBubble(msg)
                }
            }

            // Input Bar (Text + Voice + TTS toggle)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = when (voiceState) {
                                VoiceState.LISTENING -> "Listening to your voice..."
                                VoiceState.SPEAKING -> "VN Assistant is speaking..."
                                else -> "Ask VN or type a command..."
                            },
                            color = VnhitTextMuted
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("assistant_text_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedContainerColor = VnhitSurface,
                        unfocusedContainerColor = VnhitSurface,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (inputText.isNotBlank()) {
                                    val textToSend = inputText
                                    inputText = ""
                                    viewModel.executeAssistantCommand(textToSend)
                                }
                            },
                            modifier = Modifier.testTag("send_command_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = if (inputText.isNotBlank()) VnhitCyan else VnhitTextMuted
                            )
                        }
                    },
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Microphone Button
                IconButton(
                    onClick = {
                        if (voiceState == VoiceState.LISTENING) {
                            viewModel.voiceManager.stopListening()
                        } else {
                            val hasPermission = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (hasPermission) {
                                viewModel.voiceManager.startListening { spoken ->
                                    viewModel.executeAssistantCommand(spoken)
                                }
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (voiceState == VoiceState.LISTENING) VnhitPink else VnhitSurfaceElevated
                        )
                        .border(1.dp, if (voiceState == VoiceState.LISTENING) VnhitPink else VnhitBorder, CircleShape)
                        .testTag("assistant_mic_button")
                ) {
                    Icon(
                        imageVector = if (voiceState == VoiceState.LISTENING) Icons.Default.GraphicEq else Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = if (voiceState == VoiceState.LISTENING) Color.White else VnhitCyan
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // TTS Mute / Speak Toggle
                IconButton(
                    onClick = { viewModel.setTtsRepliesEnabled(!ttsRepliesEnabled) },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(VnhitSurfaceElevated)
                        .border(1.dp, VnhitBorder, CircleShape)
                        .testTag("toggle_tts_replies")
                ) {
                    Icon(
                        imageVector = if (ttsRepliesEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "TTS Voice Output",
                        tint = if (ttsRepliesEnabled) VnhitViolet else VnhitTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun VnAssistantOrb(
    voiceState: VoiceState,
    reducedMotion: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbPulse")

    val pulseScale by if (!reducedMotion) {
        infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = if (voiceState == VoiceState.LISTENING) 1.15f else 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(
                    durationMillis = if (voiceState == VoiceState.LISTENING) 800 else 2400,
                    easing = FastOutSlowInEasing
                ),
                repeatMode = RepeatMode.Reverse
            ),
            label = "orbScale"
        )
    } else {
        remember { mutableStateOf(1.0f) }
    }

    val orbBrush = when (voiceState) {
        VoiceState.LISTENING -> Brush.radialGradient(
            colors = listOf(VnhitPink, VnhitViolet, Color(0xFF1B0748))
        )
        VoiceState.SPEAKING -> Brush.radialGradient(
            colors = listOf(VnhitCyan, VnhitViolet, Color(0xFF00363F))
        )
        else -> Brush.radialGradient(
            colors = listOf(VnhitCyan, VnhitViolet, Color(0xFF080D1B))
        )
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(90.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(orbBrush)
                .border(
                    2.dp,
                    if (voiceState == VoiceState.LISTENING) VnhitPink else VnhitCyan,
                    CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (voiceState) {
                    VoiceState.LISTENING -> Icons.Default.GraphicEq
                    VoiceState.SPEAKING -> Icons.Default.RecordVoiceOver
                    else -> Icons.Default.Mic
                },
                contentDescription = "VN Assistant",
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = when (voiceState) {
                VoiceState.LISTENING -> "Listening... (Tap to stop)"
                VoiceState.SPEAKING -> "Speaking confirmation..."
                VoiceState.PROCESSING -> "Processing command..."
                else -> "Tap orb to speak"
            },
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (voiceState == VoiceState.LISTENING) VnhitPink else VnhitTextSecondary,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
fun AssistantMessageBubble(message: AssistantMessage) {
    val isUser = message.sender == MessageSender.USER

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(
                    if (isUser) VnhitSurfaceElevated else VnhitSurfaceVariant
                )
                .border(
                    1.dp,
                    if (isUser) VnhitCyan.copy(alpha = 0.5f) else VnhitBorder,
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .padding(14.dp)
        ) {
            if (message.executedAction != null) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = VnhitCyan.copy(alpha = 0.15f),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Text(
                        text = "ACTION: ${message.executedAction}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = VnhitCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = message.text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = VnhitTextPrimary
                )
            )
        }
    }
}
