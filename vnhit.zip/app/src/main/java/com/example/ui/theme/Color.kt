package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VNHIT Midnight Aurora Palette (Exact Tailwind CSS Aurora Spec)
val VnhitBackground = Color(0xFF050714)
val VnhitBackgroundObsidian = Color(0xFF03050D)
val VnhitSurface = Color(0xFF0C1226)
val VnhitSurfaceGlass = Color(0xA60C1226)
val VnhitSurfaceVariant = Color(0xFF0F172A)
val VnhitSurfaceElevated = Color(0xFF1E293B)
val VnhitBorder = Color(0x1FFFFFFF) // rgba(255, 255, 255, 0.12)
val VnhitBorderSubtle = Color(0x14FFFFFF) // rgba(255, 255, 255, 0.08)

// Exact Aurora Accents
val VnhitCyan = Color(0xFF00F0FF)
val VnhitCyanGlow = Color(0x3300F0FF)
val VnhitPink = Color(0xFFFF2A85)
val VnhitPinkGlow = Color(0x33FF2A85)
val VnhitViolet = Color(0xFFA855F7)
val VnhitVioletGlow = Color(0x33A855F7)
val VnhitLaser = Color(0xFFFF0055)
val VnhitBlue = Color(0xFF3B82F6)

// Slate Palette
val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate300 = Color(0xFFCBD5E1)
val Slate100 = Color(0xFFF1F5F9)

// Text Colors
val VnhitTextPrimary = Color(0xFFF1F5F9)
val VnhitTextSecondary = Color(0xFF94A3B8)
val VnhitTextMuted = Color(0xFF64748B)

// Badges & Actions
val VnhitSuccess = Color(0xFF10B981)
val VnhitSuccessGlow = Color(0x3310B981)
val VnhitWarning = Color(0xFFF59E0B)
val VnhitAmber = Color(0xFFFBBF24)
val VnhitError = Color(0xFFEF4444)
val VnhitOrange = Color(0xFFF97316)

// Light Horizon Colors
val VnhitLightBackground = Color(0xFFF8FAFC)
val VnhitLightSurface = Color(0xFFFFFFFF)
val VnhitLightSurfaceVariant = Color(0xFFF1F5F9)
val VnhitLightTextPrimary = Color(0xFF0F172A)
val VnhitLightTextSecondary = Color(0xFF475569)
val VnhitLightBorder = Color(0xFFE2E8F0)
