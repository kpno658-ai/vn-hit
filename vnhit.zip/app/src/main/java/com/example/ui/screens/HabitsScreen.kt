package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.HabitEntity
import com.example.data.repository.HabitWithProgress
import com.example.ui.VnhitViewModel
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.EmptyStateView
import com.example.ui.components.SectionHeader
import com.example.ui.components.VnhitCard
import com.example.ui.theme.VnhitBackground
import com.example.ui.theme.VnhitBorder
import com.example.ui.theme.VnhitCyan
import com.example.ui.theme.VnhitError
import com.example.ui.theme.VnhitOrange
import com.example.ui.theme.VnhitSuccess
import com.example.ui.theme.VnhitSurface
import com.example.ui.theme.VnhitSurfaceElevated
import com.example.ui.theme.VnhitSurfaceVariant
import com.example.ui.theme.VnhitTextMuted
import com.example.ui.theme.VnhitTextPrimary
import com.example.ui.theme.VnhitTextSecondary
import com.example.ui.theme.VnhitViolet
import com.example.ui.theme.VnhitWarning
import com.example.util.DateUtils

@Composable
fun HabitsScreen(
    viewModel: VnhitViewModel,
    modifier: Modifier = Modifier
) {
    val habitsWithProgress by viewModel.habitsList.collectAsState()
    val isDialogOpen by viewModel.isHabitDialogOpen.collectAsState()
    val activeDialogHabit by viewModel.habitDialogState.collectAsState()
    val habitToDelete by viewModel.habitToDelete.collectAsState()

    val completedTodayCount = habitsWithProgress.count { it.isCompletedToday }
    val totalHabits = habitsWithProgress.size
    val progressRate = if (totalHabits > 0) completedTodayCount.toFloat() / totalHabits else 0f

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = VnhitBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openHabitDialog(null) },
                containerColor = VnhitCyan,
                contentColor = Color(0xFF00363F),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.testTag("add_habit_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Habit")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
        ) {
            // Header
            item {
                Column {
                    Text(
                        text = "Habit Engine",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = VnhitTextPrimary
                        )
                    )
                    Text(
                        text = "Build unbreakable streaks with mathematical consistency",
                        style = MaterialTheme.typography.bodySmall.copy(color = VnhitTextSecondary)
                    )
                }
            }

            // Today's Progress Card
            item {
                VnhitCard(
                    backgroundColor = VnhitSurface,
                    borderColor = VnhitBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "TODAY'S COMPLETION",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = VnhitCyan,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "$completedTodayCount of $totalHabits Completed",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = VnhitTextPrimary
                                    )
                                )
                            }
                            Text(
                                text = "${(progressRate * 100).toInt()}%",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = if (progressRate >= 1f && totalHabits > 0) VnhitSuccess else VnhitCyan
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        LinearProgressIndicator(
                            progress = { progressRate },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (progressRate >= 1f && totalHabits > 0) VnhitSuccess else VnhitCyan,
                            trackColor = VnhitSurfaceVariant
                        )
                    }
                }
            }

            // Gamification Badges Section
            item {
                GamificationBadges(habitsWithProgress)
            }

            // Habits List Header
            item {
                SectionHeader(
                    title = "Your Habits",
                    subtitle = "Tap checkmark to toggle today's status"
                )
            }

            if (habitsWithProgress.isEmpty()) {
                item {
                    EmptyStateView(
                        icon = Icons.Default.TaskAlt,
                        title = "No habits tracked yet",
                        description = "Start small. Adding one positive daily routine creates exponential progress over time.",
                        actionButtonText = "+ Add First Habit",
                        onActionClick = { viewModel.openHabitDialog(null) }
                    )
                }
            } else {
                items(habitsWithProgress, key = { it.habit.id }) { item ->
                    HabitCardItem(
                        item = item,
                        onToggle = {
                            viewModel.toggleHabit(
                                habitId = item.habit.id,
                                currentStatus = item.isCompletedToday
                            )
                        },
                        onEdit = { viewModel.openHabitDialog(item.habit) },
                        onDelete = { viewModel.requestDeleteHabit(item.habit) }
                    )
                }
            }
        }
    }

    // Dialogs
    if (isDialogOpen && activeDialogHabit != null) {
        HabitEditDialog(
            initialHabit = activeDialogHabit!!,
            onDismiss = { viewModel.closeHabitDialog() },
            onSave = { name, description, category, targetDays, colorHex ->
                viewModel.saveHabit(
                    name = name,
                    description = description,
                    category = category,
                    targetDays = targetDays,
                    colorHex = colorHex,
                    id = activeDialogHabit!!.id
                )
            }
        )
    }

    if (habitToDelete != null) {
        DeleteConfirmationDialog(
            title = "Delete Habit?",
            message = "Are you sure you want to delete \"${habitToDelete!!.name}\"? All history and streak records for this habit will be removed.",
            onConfirm = { viewModel.confirmDeleteHabit() },
            onDismiss = { viewModel.cancelDeleteHabit() }
        )
    }
}

@Composable
fun HabitCardItem(
    item: HabitWithProgress,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val habit = item.habit

    VnhitCard(
        borderColor = if (item.isCompletedToday) VnhitSuccess.copy(alpha = 0.5f) else VnhitBorder,
        backgroundColor = VnhitSurface,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("habit_card_${habit.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Check Toggle Box (Exact HTML Style)
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (item.isCompletedToday) VnhitCyan.copy(alpha = 0.2f) else com.example.ui.theme.Slate900
                        )
                        .border(
                            2.dp,
                            if (item.isCompletedToday) VnhitCyan else com.example.ui.theme.Slate700,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable(onClick = onToggle)
                        .testTag("toggle_habit_${habit.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (item.isCompletedToday) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Completed",
                            tint = VnhitCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = habit.name,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (item.isCompletedToday) com.example.ui.theme.Slate400 else com.example.ui.theme.Slate100,
                            textDecoration = if (item.isCompletedToday) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (habit.description.isNotBlank()) {
                        Text(
                            text = habit.description,
                            style = MaterialTheme.typography.bodySmall.copy(color = com.example.ui.theme.Slate400),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = VnhitSurfaceElevated
                        ) {
                            Text(
                                text = habit.category,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = VnhitCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Streaks Badge
                Column(horizontalAlignment = Alignment.End) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(
                                if (item.currentStreak > 0) VnhitOrange.copy(alpha = 0.15f) else VnhitSurfaceElevated,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "Streak",
                            tint = if (item.currentStreak > 0) VnhitOrange else VnhitTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${item.currentStreak}d",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (item.currentStreak > 0) VnhitOrange else VnhitTextMuted
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Best: ${item.bestStreak}d",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = VnhitTextMuted,
                            fontSize = 10.sp
                        )
                    )
                }

                // Options
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("edit_habit_${habit.id}")
                ) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Edit",
                        tint = VnhitTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("delete_habit_${habit.id}")
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = VnhitError,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 7-day Mini Heatmap dots
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(VnhitSurfaceElevated, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Last 7 Days:",
                    style = MaterialTheme.typography.labelSmall.copy(color = VnhitTextSecondary)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item.recent7Days.forEach { (_, isDone) ->
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isDone) VnhitSuccess else VnhitBorder
                                )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GamificationBadges(habits: List<HabitWithProgress>) {
    val totalCompletions = habits.sumOf { it.totalCompletions }
    val maxStreak = habits.maxOfOrNull { it.bestStreak } ?: 0
    val totalHabitsCount = habits.size

    val badges = listOf(
        BadgeInfo("Starter", "First habit created", Icons.Default.TaskAlt, totalHabitsCount >= 1),
        BadgeInfo("Ignition", "1st completion recorded", Icons.Default.Check, totalCompletions >= 1),
        BadgeInfo("3-Day Surge", "3-day streak reached", Icons.Default.LocalFireDepartment, maxStreak >= 3),
        BadgeInfo("Mastery", "7-day streak achieved", Icons.Default.MilitaryTech, maxStreak >= 7),
        BadgeInfo("Titan", "14-day unbreakable chain", Icons.Default.EmojiEvents, maxStreak >= 14)
    )

    VnhitCard(
        backgroundColor = VnhitSurface,
        borderColor = VnhitBorder,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = VnhitWarning,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ACHIEVEMENT BADGES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = VnhitWarning,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(badges) { badge ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(80.dp)
                            .background(
                                if (badge.isUnlocked) VnhitSurfaceElevated else VnhitSurfaceVariant.copy(alpha = 0.5f),
                                RoundedCornerShape(10.dp)
                            )
                            .border(
                                1.dp,
                                if (badge.isUnlocked) VnhitWarning.copy(alpha = 0.6f) else VnhitBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .padding(vertical = 10.dp, horizontal = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(
                                    if (badge.isUnlocked) VnhitWarning.copy(alpha = 0.2f) else VnhitBorder
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = badge.icon,
                                contentDescription = badge.name,
                                tint = if (badge.isUnlocked) VnhitWarning else VnhitTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = badge.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (badge.isUnlocked) VnhitTextPrimary else VnhitTextMuted,
                                fontSize = 10.sp
                            ),
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

private data class BadgeInfo(
    val name: String,
    val desc: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val isUnlocked: Boolean
)

@Composable
fun HabitEditDialog(
    initialHabit: HabitEntity,
    onDismiss: () -> Unit,
    onSave: (name: String, description: String, category: String, targetDays: Int, colorHex: String) -> Unit
) {
    var name by remember { mutableStateOf(initialHabit.name) }
    var description by remember { mutableStateOf(initialHabit.description) }
    var category by remember { mutableStateOf(initialHabit.category) }
    var targetDays by remember { mutableIntStateOf(initialHabit.targetDaysPerWeek) }
    var colorHex by remember { mutableStateOf(initialHabit.colorHex) }

    val categories = listOf("Productivity", "Health", "Fitness", "Learning", "Mindset")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialHabit.id == 0L) "New Habit" else "Edit Habit",
                color = VnhitTextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    placeholder = { Text("Habit name (e.g., Daily Code)", color = VnhitTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("habit_name_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedContainerColor = VnhitSurfaceVariant,
                        unfocusedContainerColor = VnhitSurfaceVariant,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text("Description / Cue (optional)", color = VnhitTextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("habit_desc_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VnhitCyan,
                        unfocusedBorderColor = VnhitBorder,
                        focusedContainerColor = VnhitSurfaceVariant,
                        unfocusedContainerColor = VnhitSurfaceVariant,
                        focusedTextColor = VnhitTextPrimary,
                        unfocusedTextColor = VnhitTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Category", color = VnhitTextSecondary, style = MaterialTheme.typography.labelSmall)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        val isSelected = category == cat
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) VnhitCyan else VnhitSurfaceVariant,
                            modifier = Modifier
                                .border(1.dp, if (isSelected) VnhitCyan else VnhitBorder, RoundedCornerShape(14.dp))
                                .clickable { category = cat }
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) Color(0xFF00363F) else VnhitTextSecondary,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        },
        containerColor = VnhitSurface,
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name, description, category, targetDays, colorHex)
                    }
                },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = VnhitCyan,
                    contentColor = Color(0xFF00363F)
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("save_habit_button")
            ) {
                Text("Save Habit", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("cancel_habit_button")
            ) {
                Text("Cancel", color = VnhitTextSecondary)
            }
        }
    )
}
