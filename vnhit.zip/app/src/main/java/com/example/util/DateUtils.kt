package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("EEE, MMM d, yyyy", Locale.US)
    private val monthYearFormat = SimpleDateFormat("MMMM yyyy", Locale.US)
    private val dayOfWeekFormat = SimpleDateFormat("EEE", Locale.US)
    private val dayOfMonthFormat = SimpleDateFormat("d", Locale.US)
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.US)
    private val time24Format = SimpleDateFormat("HH:mm", Locale.US)

    fun getTodayIso(): String {
        return isoFormat.format(Date())
    }

    fun formatToIso(calendar: Calendar): String {
        return isoFormat.format(calendar.time)
    }

    fun parseIso(isoDate: String): Calendar? {
        return try {
            val date = isoFormat.parse(isoDate) ?: return null
            Calendar.getInstance().apply { time = date }
        } catch (_: Exception) {
            null
        }
    }

    fun formatForDisplay(isoDate: String): String {
        return try {
            val date = isoFormat.parse(isoDate) ?: return isoDate
            displayFormat.format(date)
        } catch (_: Exception) {
            isoDate
        }
    }

    fun formatMonthYear(calendar: Calendar): String {
        return monthYearFormat.format(calendar.time)
    }

    fun formatTimeDisplay(time24: String): String {
        return try {
            val date = time24Format.parse(time24) ?: return time24
            timeFormat.format(date)
        } catch (_: Exception) {
            time24
        }
    }

    fun getDaysAgoIso(daysAgo: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return isoFormat.format(cal.time)
    }

    fun getDaysAheadIso(daysAhead: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, daysAhead)
        return isoFormat.format(cal.time)
    }

    /**
     * Calculates consecutive daily streak for a habit given its completed date strings ("yyyy-MM-dd").
     * Returns a Pair(currentStreak, bestStreak).
     */
    fun calculateStreaks(completedIsoDates: Set<String>, todayIso: String = getTodayIso()): Pair<Int, Int> {
        if (completedIsoDates.isEmpty()) return Pair(0, 0)

        // 1. Calculate Current Streak
        var currentStreak = 0
        val todayCal = parseIso(todayIso) ?: Calendar.getInstance()

        // Check if today is completed
        val todayCompleted = completedIsoDates.contains(todayIso)
        val checkCal = Calendar.getInstance().apply { time = todayCal.time }

        if (!todayCompleted) {
            // If today is not completed, check if yesterday was completed
            checkCal.add(Calendar.DAY_OF_YEAR, -1)
            val yesterdayIso = isoFormat.format(checkCal.time)
            if (completedIsoDates.contains(yesterdayIso)) {
                // Streak is currently active from yesterday
                currentStreak = 1
                checkCal.add(Calendar.DAY_OF_YEAR, -1)
                while (completedIsoDates.contains(isoFormat.format(checkCal.time))) {
                    currentStreak++
                    checkCal.add(Calendar.DAY_OF_YEAR, -1)
                }
            } else {
                currentStreak = 0
            }
        } else {
            // Today is completed, count back
            currentStreak = 1
            checkCal.add(Calendar.DAY_OF_YEAR, -1)
            while (completedIsoDates.contains(isoFormat.format(checkCal.time))) {
                currentStreak++
                checkCal.add(Calendar.DAY_OF_YEAR, -1)
            }
        }

        // 2. Calculate Best Historical Streak
        val sortedDates = completedIsoDates.mapNotNull { parseIso(it)?.timeInMillis }.sorted()
        var bestStreak = 0
        var tempStreak = 0
        var prevCal: Calendar? = null

        for (timeMillis in sortedDates) {
            val currCal = Calendar.getInstance().apply { timeInMillis = timeMillis }
            if (prevCal == null) {
                tempStreak = 1
            } else {
                val expectedCal = Calendar.getInstance().apply {
                    time = prevCal.time
                    add(Calendar.DAY_OF_YEAR, 1)
                }
                if (isoFormat.format(expectedCal.time) == isoFormat.format(currCal.time)) {
                    tempStreak++
                } else if (isoFormat.format(prevCal.time) != isoFormat.format(currCal.time)) {
                    tempStreak = 1
                }
            }
            if (tempStreak > bestStreak) {
                bestStreak = tempStreak
            }
            prevCal = currCal
        }

        return Pair(currentStreak, maxOf(bestStreak, currentStreak))
    }
}
