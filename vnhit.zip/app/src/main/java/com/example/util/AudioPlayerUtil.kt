package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import com.example.R

class AudioPlayerUtil(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var isPlaying = false
    private var onCompletionCallback: (() -> Unit)? = null

    fun playWelcomeGreeting(onStarted: () -> Unit = {}, onCompleted: () -> Unit = {}) {
        stop()
        onCompletionCallback = onCompleted

        try {
            requestAudioFocus()

            mediaPlayer = MediaPlayer.create(context, R.raw.welcome_greeting)?.apply {
                setOnCompletionListener {
                    this@AudioPlayerUtil.isPlaying = false
                    abandonAudioFocus()
                    onCompletionCallback?.invoke()
                }
                setOnErrorListener { _, _, _ ->
                    this@AudioPlayerUtil.isPlaying = false
                    abandonAudioFocus()
                    true
                }
                start()
                this@AudioPlayerUtil.isPlaying = true
                onStarted()
            }
        } catch (_: Exception) {
            this@AudioPlayerUtil.isPlaying = false
            abandonAudioFocus()
            onCompleted()
        }
    }

    fun isCurrentlyPlaying(): Boolean = isPlaying

    fun stop() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
            mediaPlayer = null
            isPlaying = false
            abandonAudioFocus()
        } catch (_: Exception) {
            // Ignore cleanup errors
        }
    }

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(playbackAttributes)
                .build()
            audioManager?.requestAudioFocus(focusRequest)
        } else {
            @Suppress("DEPRECATION")
            audioManager?.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
            )
        }
    }

    private fun abandonAudioFocus() {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                @Suppress("DEPRECATION")
                audioManager?.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
            // Ignore
        }
    }
}
