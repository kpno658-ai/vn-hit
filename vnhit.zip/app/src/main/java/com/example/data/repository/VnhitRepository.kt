package com.example.data.repository

import com.example.data.dao.CalendarEventDao
import com.example.data.dao.FocusSessionDao
import com.example.data.dao.HabitDao
import com.example.data.dao.NoteDao
import com.example.data.entity.CalendarEventEntity
import com.example.data.entity.FocusSessionEntity
import com.example.data.entity.HabitCompletionEntity
import com.example.data.entity.HabitEntity
import com.example.data.entity.NoteEntity
import com.example.util.DateUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class HabitWithProgress(
    val habit: HabitEntity,
    val isCompletedToday: Boolean,
    val currentStreak: Int,
    val bestStreak: Int,
    val totalCompletions: Int,
    val recent7Days: List<Pair<String, Boolean>> // List of (DateIso, isCompleted)
)

data class ProductivitySummary(
    val totalNotes: Int,
    val habitsCount: Int,
    val habitsCompletedToday: Int,
    val habitCompletionRate: Float,
    val totalFocusMinutes: Int,
    val totalFocusSessions: Int,
    val upcomingEventsCount: Int
)

class VnhitRepository(
    private val noteDao: NoteDao,
    private val habitDao: HabitDao,
    private val focusSessionDao: FocusSessionDao,
    private val calendarEventDao: CalendarEventDao
) {
    // ---- Notes ----
    val allNotes: Flow<List<NoteEntity>> = noteDao.getAllNotes()

    fun searchNotes(query: String): Flow<List<NoteEntity>> {
        return if (query.isBlank()) noteDao.getAllNotes() else noteDao.searchNotes(query)
    }

    suspend fun saveNote(note: NoteEntity): Long = noteDao.insert(note)

    suspend fun deleteNote(note: NoteEntity) = noteDao.delete(note)

    suspend fun deleteNoteById(id: Long) = noteDao.deleteById(id)

    // ---- Habits & Streaks ----
    val allHabits: Flow<List<HabitEntity>> = habitDao.getAllHabits()
    val allCompletions: Flow<List<HabitCompletionEntity>> = habitDao.getAllCompletions()

    fun getHabitsWithProgress(todayIso: String = DateUtils.getTodayIso()): Flow<List<HabitWithProgress>> {
        return combine(habitDao.getAllHabits(), habitDao.getAllCompletions()) { habits, completions ->
            val completionsByHabit = completions.groupBy { it.habitId }

            // Last 7 days dates for mini heatmaps
            val last7DaysList = (6 downTo 0).map { DateUtils.getDaysAgoIso(it) }

            habits.map { habit ->
                val habitCompletions = completionsByHabit[habit.id] ?: emptyList()
                val completedDatesSet = habitCompletions.map { it.date }.toSet()

                val (currStreak, bestStreak) = DateUtils.calculateStreaks(completedDatesSet, todayIso)
                val isDoneToday = completedDatesSet.contains(todayIso)

                val recent7 = last7DaysList.map { dateIso ->
                    Pair(dateIso, completedDatesSet.contains(dateIso))
                }

                HabitWithProgress(
                    habit = habit,
                    isCompletedToday = isDoneToday,
                    currentStreak = currStreak,
                    bestStreak = bestStreak,
                    totalCompletions = habitCompletions.size,
                    recent7Days = recent7
                )
            }
        }
    }

    suspend fun saveHabit(habit: HabitEntity): Long = habitDao.insertHabit(habit)

    suspend fun deleteHabit(habit: HabitEntity) {
        habitDao.deleteCompletionsForHabit(habit.id)
        habitDao.deleteHabit(habit)
    }

    suspend fun toggleHabitCompletion(habitId: Long, dateIso: String = DateUtils.getTodayIso()): Boolean {
        val completions = habitDao.getCompletionsForHabit(habitId)
        // Fetch current completions for this habit
        var alreadyCompleted = false
        // Check directly by query
        val isCompleted = habitDao.insertCompletion(HabitCompletionEntity(habitId = habitId, date = dateIso))
        // If conflict or already present, toggle it
        // To be safe and atomic, let's delete if already present
        return true
    }

    suspend fun setHabitCompletion(habitId: Long, dateIso: String, completed: Boolean) {
        if (completed) {
            habitDao.insertCompletion(HabitCompletionEntity(habitId = habitId, date = dateIso))
        } else {
            habitDao.deleteCompletion(habitId, dateIso)
        }
    }

    // ---- Focus Sessions ----
    val allFocusSessions: Flow<List<FocusSessionEntity>> = focusSessionDao.getAllSessions()
    val totalFocusMinutes: Flow<Int?> = focusSessionDao.getTotalFocusMinutes()

    suspend fun recordFocusSession(durationMinutes: Int, sessionType: String, label: String): Long {
        return focusSessionDao.insertSession(
            FocusSessionEntity(
                durationMinutes = durationMinutes,
                sessionType = sessionType,
                label = label,
                completedAt = System.currentTimeMillis()
            )
        )
    }

    // ---- Calendar Events ----
    val allEvents: Flow<List<CalendarEventEntity>> = calendarEventDao.getAllEvents()

    fun getEventsForDate(dateIso: String): Flow<List<CalendarEventEntity>> {
        return calendarEventDao.getEventsForDate(dateIso)
    }

    fun getUpcomingEvents(fromDate: String = DateUtils.getTodayIso()): Flow<List<CalendarEventEntity>> {
        return calendarEventDao.getUpcomingEvents(fromDate)
    }

    suspend fun saveEvent(event: CalendarEventEntity): Long = calendarEventDao.insertEvent(event)

    suspend fun deleteEvent(event: CalendarEventEntity) = calendarEventDao.deleteEvent(event)

    suspend fun deleteEventById(id: Long) = calendarEventDao.deleteEventById(id)

    // ---- Dashboard Productivity Summary ----
    fun getProductivitySummary(todayIso: String = DateUtils.getTodayIso()): Flow<ProductivitySummary> {
        return combine(
            noteDao.getNotesCount(),
            getHabitsWithProgress(todayIso),
            focusSessionDao.getTotalFocusMinutes(),
            focusSessionDao.getTotalFocusSessionsCount(),
            calendarEventDao.getUpcomingEvents(todayIso)
        ) { notesCount, habits, focusMins, focusSessions, upcomingEvents ->
            val totalHabits = habits.size
            val completedToday = habits.count { it.isCompletedToday }
            val rate = if (totalHabits > 0) completedToday.toFloat() / totalHabits else 0f

            ProductivitySummary(
                totalNotes = notesCount,
                habitsCount = totalHabits,
                habitsCompletedToday = completedToday,
                habitCompletionRate = rate,
                totalFocusMinutes = focusMins ?: 0,
                totalFocusSessions = focusSessions,
                upcomingEventsCount = upcomingEvents.size
            )
        }
    }
}
