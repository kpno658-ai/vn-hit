package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val date: String, // "yyyy-MM-dd"
    val startTime: String = "09:00", // "HH:mm"
    val endTime: String = "10:00", // "HH:mm"
    val category: String = "Work",
    val colorHex: String = "#55E6FF",
    val createdAt: Long = System.currentTimeMillis()
)
