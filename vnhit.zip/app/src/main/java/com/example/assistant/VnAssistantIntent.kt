package com.example.assistant

import com.example.ui.NavTab

sealed class VnAssistantIntent {
    data class NavigateTo(val tab: NavTab) : VnAssistantIntent()
    data class CreateNote(val title: String, val content: String, val category: String = "General") : VnAssistantIntent()
    data class FindNotes(val query: String) : VnAssistantIntent()
    data class CreateHabit(val name: String, val category: String = "Productivity") : VnAssistantIntent()
    data class CompleteHabit(val habitName: String) : VnAssistantIntent()
    data class StartFocus(val minutes: Int = 25) : VnAssistantIntent()
    data object PauseFocus : VnAssistantIntent()
    data object ResumeFocus : VnAssistantIntent()
    data object ResetFocus : VnAssistantIntent()
    data class CreateEvent(val title: String, val dateIso: String, val startTime: String = "09:00") : VnAssistantIntent()
    data object QueryProgress : VnAssistantIntent()
    data class ChangeTheme(val themeName: String) : VnAssistantIntent()
    data class ChangeLanguage(val langCode: String) : VnAssistantIntent()
    data object PlayWelcomeGreeting : VnAssistantIntent()
    data class GeneralQuery(val userText: String) : VnAssistantIntent()
    data class Unknown(val rawText: String) : VnAssistantIntent()
}

data class AssistantMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val executedAction: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

enum class MessageSender {
    USER,
    ASSISTANT
}
