package com.example.assistant

import com.example.ui.NavTab
import com.example.util.DateUtils
import java.util.Locale

object VnCommandEngine {

    fun parseCommand(input: String, languageCode: String = "en"): VnAssistantIntent {
        val text = input.trim().lowercase(Locale.ROOT)
        if (text.isBlank()) return VnAssistantIntent.Unknown(input)

        // 1. Play Welcome Voice Greeting
        if (text.contains("welcome") || text.contains("meet vnhit") || text.contains("play greeting") ||
            text.contains("voice greeting") || text.contains("नमस्ते") || text.contains("intro") || text.contains("hello vn")
        ) {
            return VnAssistantIntent.PlayWelcomeGreeting
        }

        // 2. Navigation
        if (text.contains("open note") || text.contains("go to note") || text.contains("show note") ||
            text.contains("notes kholo") || text.contains("नोट्स खोलो") || text.contains("abrir notas") || text.contains("ouvrir les notes")
        ) {
            return VnAssistantIntent.NavigateTo(NavTab.NOTES)
        }
        if (text.contains("open habit") || text.contains("go to habit") || text.contains("habits kholo") ||
            text.contains("आदतें खोलो") || text.contains("abrir hábitos")
        ) {
            return VnAssistantIntent.NavigateTo(NavTab.HABITS)
        }
        if (text.contains("open focus") || text.contains("go to focus") || text.contains("timer kholo") ||
            text.contains("टाइमर खोलो") || text.contains("abrir temporizador")
        ) {
            return VnAssistantIntent.NavigateTo(NavTab.FOCUS)
        }
        if (text.contains("open calendar") || text.contains("go to calendar") || text.contains("calendar kholo") ||
            text.contains("कैलेंडर खोलो") || text.contains("abrir calendario")
        ) {
            return VnAssistantIntent.NavigateTo(NavTab.CALENDAR)
        }
        if (text.contains("go home") || text.contains("dashboard") || text.contains("home kholo")) {
            return VnAssistantIntent.NavigateTo(NavTab.DASHBOARD)
        }
        if (text.contains("settings") || text.contains("open settings") || text.contains("सेटिंग्स")) {
            return VnAssistantIntent.NavigateTo(NavTab.SETTINGS)
        }

        // 3. Focus Timer Controls
        if (text.contains("pause timer") || text.contains("pause focus") || text.contains("timer roko") ||
            text.contains("टाइमर रोको") || text.contains("pausar temporizador")
        ) {
            return VnAssistantIntent.PauseFocus
        }
        if (text.contains("resume timer") || text.contains("resume focus") || text.contains("timer chalu karo") ||
            text.contains("फिर से शुरू करो") || text.contains("reanudar")
        ) {
            return VnAssistantIntent.ResumeFocus
        }
        if (text.contains("reset timer") || text.contains("reset focus") || text.contains("टाइमर रीसेट")) {
            return VnAssistantIntent.ResetFocus
        }
        if (text.contains("start focus") || text.contains("start timer") || text.contains("focus session") ||
            text.contains("minute focus") || text.contains("min focus") || text.contains("focus for") ||
            (text.contains("focus") && (text.contains("min") || text.contains("minute"))) ||
            text.contains("फोकस शुरू") ||
            text.contains("iniciar temporizador") || text.contains("démarrer le focus")
        ) {
            val minutesRegex = Regex("""(\d+)\s*(?:min|minute|minutes|m)""")
            val match = minutesRegex.find(text)
            val minutes = match?.groupValues?.get(1)?.toIntOrNull() ?: 25
            return VnAssistantIntent.StartFocus(minutes)
        }

        // 4. Notes: Create or Find
        if (text.startsWith("find note") || text.startsWith("search note") || text.startsWith("search ") ||
            text.startsWith("dhoondo ") || text.startsWith("खोजो ")
        ) {
            val query = text.replace(Regex("""^(?:find note|search note|search|dhoondo|खोजो)\s*(?:for|about)?\s*"""), "").trim()
            return VnAssistantIntent.FindNotes(query)
        }
        if (text.contains("create note") || text.contains("new note") || text.contains("add note") ||
            text.contains("note banao") || text.contains("नोट बनाओ") || text.contains("crear nota") ||
            text.contains("créer une note") || text.contains("notiz erstellen")
        ) {
            var title = text.replace(Regex("""^(?:create note|new note|add note|note banao|नोट बनाओ|crear nota|créer une note|notiz erstellen)\s*(?:about|titled|for|ke bare me)?\s*"""), "")
                .replace(Regex("""ke bare me$"""), "").trim()
            if (title.isBlank()) title = "Quick Note from VN Assistant"
            val capitalizedTitle = title.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
            return VnAssistantIntent.CreateNote(
                title = capitalizedTitle,
                content = "Captured via VN Assistant voice/text input.",
                category = "General"
            )
        }

        // 5. Habits: Create or Complete
        if (text.contains("mark ") && (text.contains("complete") || text.contains("done")) ||
            text.contains("complete habit") || text.contains("habit complete") ||
            text.contains("आदत पूरी") || text.contains("completar hábito")
        ) {
            val habitName = text.replace(Regex("""^(?:mark|complete habit|habit complete|completar hábito)\s*"""), "")
                .replace(Regex("""\s*(?:as complete|complete|done|karo|करो)$"""), "")
                .trim()
            return VnAssistantIntent.CompleteHabit(habitName)
        }
        if (text.contains("create habit") || text.contains("add habit") || text.contains("new habit") ||
            text.contains("make a habit") || text.contains("habit banao") || text.contains("आदत जोड़ो") ||
            text.contains("crear hábito")
        ) {
            val habitName = text.replace(Regex("""^(?:create habit|add habit|new habit|make a habit|habit banao|आदत जोड़ो|crear hábito)\s*(?:called|named|for)?\s*"""), "")
                .trim()
            val finalName = if (habitName.isBlank()) "Daily Routine" else habitName.replaceFirstChar { it.uppercase() }
            return VnAssistantIntent.CreateHabit(finalName)
        }

        // 6. Calendar Events
        if (text.contains("add event") || text.contains("create event") || text.contains("schedule event") ||
            text.contains("plan study") || text.contains("event add karo") || text.contains("इवेंट जोड़ो") ||
            text.contains("crear evento")
        ) {
            var eventTitle = text.replace(Regex("""^(?:add event|create event|schedule event|plan study|event add karo|इवेंट जोड़ो|crear evento)\s*(?:for|about)?\s*"""), "")
                .trim()
            if (eventTitle.isBlank()) eventTitle = "Scheduled Session"
            return VnAssistantIntent.CreateEvent(
                title = eventTitle.replaceFirstChar { it.uppercase() },
                dateIso = DateUtils.getTodayIso(),
                startTime = "10:00"
            )
        }

        // 7. Progress & Summary Query
        if (text.contains("what have i completed") || text.contains("today's progress") ||
            text.contains("show progress") || text.contains("summary") || text.contains("aaj kya hua") ||
            text.contains("आज की प्रोग्रेस") || text.contains("progreso de hoy") || text.contains("résumé")
        ) {
            return VnAssistantIntent.QueryProgress
        }

        // 8. Theme / Language Settings
        if (text.contains("dark theme") || text.contains("dark mode") || text.contains("black theme")) {
            return VnAssistantIntent.ChangeTheme("dark")
        }
        if (text.contains("light theme") || text.contains("light mode")) {
            return VnAssistantIntent.ChangeTheme("light")
        }
        if (text.contains("hindi") || text.contains("हिंदी")) {
            return VnAssistantIntent.ChangeLanguage("hi")
        }
        if (text.contains("english") || text.contains("अंग्रेजी")) {
            return VnAssistantIntent.ChangeLanguage("en")
        }
        if (text.contains("spanish") || text.contains("español")) {
            return VnAssistantIntent.ChangeLanguage("es")
        }

        // 9. General Query / Friendly Response
        if (text.contains("hello") || text.contains("hi") || text.contains("hey") ||
            text.contains("namaste") || text.contains("hola") || text.contains("bonjour")
        ) {
            return VnAssistantIntent.GeneralQuery(input)
        }

        return VnAssistantIntent.Unknown(input)
    }

    fun getResponseText(intent: VnAssistantIntent, lang: String = "en", extraInfo: String = ""): String {
        return when (intent) {
            is VnAssistantIntent.PlayWelcomeGreeting -> when (lang) {
                "hi" -> "VNHIT में आपका स्वागत है! आपका स्वागत संदेश चल रहा है। 'छोटे कदम। शांत पुरस्कार। वास्तविक प्रगति।'"
                "es" -> "¡Bienvenido a VNHIT! Reproduciendo mensaje de bienvenida."
                "fr" -> "Bienvenue sur VNHIT ! Lecture du message de bienvenue."
                else -> "Welcome to VNHIT! Playing your warm voice greeting now. 'Small steps. Quiet rewards. Real progress.'"
            }
            is VnAssistantIntent.NavigateTo -> when (lang) {
                "hi" -> "मैं आपको ${intent.tab.name.lowercase()} स्क्रीन पर ले जा रहा हूँ।"
                "es" -> "Navegando a la pantalla ${intent.tab.name.lowercase()}."
                else -> "Navigating to ${intent.tab.name.lowercase()} screen."
            }
            is VnAssistantIntent.CreateNote -> when (lang) {
                "hi" -> "नोट '${intent.title}' सफलतापूर्वक स्थानीय रूप से सहेजा गया।"
                "es" -> "Nota '${intent.title}' guardada localmente con éxito."
                else -> "Note '${intent.title}' saved locally to Room database."
            }
            is VnAssistantIntent.FindNotes -> when (lang) {
                "hi" -> "'${intent.query}' के लिए नोट्स खोजे गए।"
                "es" -> "Filtrando notas por '${intent.query}'."
                else -> "Found notes matching '${intent.query}'."
            }
            is VnAssistantIntent.CreateHabit -> when (lang) {
                "hi" -> "नई आदत '${intent.name}' आपके ट्रैकर में जोड़ी गई।"
                "es" -> "Nuevo hábito '${intent.name}' agregado a tu rutina."
                else -> "Habit '${intent.name}' added to your daily engine."
            }
            is VnAssistantIntent.CompleteHabit -> when (lang) {
                "hi" -> "बधाई! आदत '${intent.habitName}' आज पूरी हो गई।"
                "es" -> "¡Excelente! Hábito '${intent.habitName}' marcado como completado."
                else -> "Marked habit '${intent.habitName}' completed for today. Streak updated!"
            }
            is VnAssistantIntent.StartFocus -> when (lang) {
                "hi" -> "आपका ${intent.minutes} मिनट का फोकस टाइमर शुरू कर दिया गया है। ध्यान केंद्रित रखें!"
                "es" -> "Sesión de enfoque de ${intent.minutes} minutos iniciada. ¡A concentrarse!"
                else -> "Started your ${intent.minutes}-minute precision focus session. Stay in the flow!"
            }
            is VnAssistantIntent.PauseFocus -> when (lang) {
                "hi" -> "फोकस टाइमर रोक दिया गया है।"
                "es" -> "Temporizador de enfoque en pausa."
                else -> "Focus timer paused."
            }
            is VnAssistantIntent.ResumeFocus -> when (lang) {
                "hi" -> "फोकस टाइमर फिर से शुरू हो गया है।"
                "es" -> "Temporizador de enfoque reanudado."
                else -> "Focus timer resumed."
            }
            is VnAssistantIntent.ResetFocus -> when (lang) {
                "hi" -> "फोकस टाइमर रीसेट कर दिया गया है।"
                "es" -> "Temporizador de enfoque restablecido."
                else -> "Focus timer reset to default."
            }
            is VnAssistantIntent.CreateEvent -> when (lang) {
                "hi" -> "इवेंट '${intent.title}' आपके इन-ऐप कैलेंडर में जोड़ा गया।"
                "es" -> "Evento '${intent.title}' programado en tu calendario."
                else -> "In-app event '${intent.title}' scheduled on ${intent.dateIso} at ${intent.startTime}."
            }
            is VnAssistantIntent.QueryProgress -> when (lang) {
                "hi" -> "आज की प्रगति: $extraInfo 'छोटे कदम। शांत पुरस्कार। वास्तविक प्रगति।'"
                "es" -> "Tu progreso de hoy: $extraInfo"
                else -> "Here is your progress today: $extraInfo. Remember: 'Small steps. Quiet rewards. Real progress.'"
            }
            is VnAssistantIntent.ChangeTheme -> when (lang) {
                "hi" -> "थीम बदल दी गई है।"
                "es" -> "Tema actualizado."
                else -> "Theme changed to ${intent.themeName}."
            }
            is VnAssistantIntent.ChangeLanguage -> when (lang) {
                "hi" -> "भाषा बदलकर हिंदी कर दी गई है।"
                "es" -> "Idioma cambiado a español."
                else -> "Assistant language updated to ${intent.langCode}."
            }
            is VnAssistantIntent.GeneralQuery -> when (lang) {
                "hi" -> "नमस्ते! मैं वीएन असिस्टेंट हूँ। आप मुझसे नोट्स बनाने, आदतें ट्रैक करने, या 25 मिनट का फोकस टाइमर शुरू करने के लिए कह सकते हैं।"
                "es" -> "¡Hola! Soy VN Assistant. Puedes pedirme que cree notas, registre hábitos o inicie tu temporizador de concentración."
                else -> "Hello! I am VN Assistant (Virtual Natural Language Assistant). I can help you create notes, track daily habits, start focus sessions, and plan events completely offline."
            }
            is VnAssistantIntent.Unknown -> when (lang) {
                "hi" -> "मैं समझ नहीं पाया। आप कह सकते हैं: 'नोट बनाओ', '25 मिनट फोकस शुरू करो', या 'आदत पूरी करो'।"
                "es" -> "No pude entender esa orden. Intenta con: 'Crear nota', 'Iniciar 25 min de enfoque' o 'Marcar hábito completado'."
                else -> "I didn't recognize that command. Try asking: 'Start 25m focus', 'Create a note about my project', 'Mark habit complete', or 'Show my progress'."
            }
        }
    }
}
