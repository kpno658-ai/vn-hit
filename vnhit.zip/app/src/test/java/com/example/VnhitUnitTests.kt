package com.example

import com.example.util.DateUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class VnhitUnitTests {

    @Test
    fun testEmptyCompletionsStreak() {
        val (currentStreak, bestStreak) = DateUtils.calculateStreaks(emptySet(), "2026-10-20")
        assertEquals(0, currentStreak)
        assertEquals(0, bestStreak)
    }

    @Test
    fun testSingleDayTodayStreak() {
        val completedDates = setOf("2026-10-20")
        val (currentStreak, bestStreak) = DateUtils.calculateStreaks(completedDates, "2026-10-20")
        assertEquals(1, currentStreak)
        assertEquals(1, bestStreak)
    }

    @Test
    fun testYesterdayCompletedActiveStreak() {
        // Today is not marked yet, but yesterday was -> active streak 1
        val completedDates = setOf("2026-10-19")
        val (currentStreak, bestStreak) = DateUtils.calculateStreaks(completedDates, "2026-10-20")
        assertEquals(1, currentStreak)
        assertEquals(1, bestStreak)
    }

    @Test
    fun testConsecutiveThreeDaysStreak() {
        val completedDates = setOf("2026-10-18", "2026-10-19", "2026-10-20")
        val (currentStreak, bestStreak) = DateUtils.calculateStreaks(completedDates, "2026-10-20")
        assertEquals(3, currentStreak)
        assertEquals(3, bestStreak)
    }

    @Test
    fun testBrokenStreakHistoricalBest() {
        // 4 consecutive days in past, gap, then 1 day yesterday
        val completedDates = setOf(
            "2026-10-10", "2026-10-11", "2026-10-12", "2026-10-13",
            "2026-10-19"
        )
        val (currentStreak, bestStreak) = DateUtils.calculateStreaks(completedDates, "2026-10-20")
        assertEquals(1, currentStreak) // Yesterday was done
        assertEquals(4, bestStreak) // 4 days in past
    }

    @Test
    fun testStreakWithGapReturnsZeroCurrentStreak() {
        // Completed 3 days ago, but not yesterday and not today
        val completedDates = setOf("2026-10-15", "2026-10-16", "2026-10-17")
        val (currentStreak, bestStreak) = DateUtils.calculateStreaks(completedDates, "2026-10-20")
        assertEquals(0, currentStreak)
        assertEquals(3, bestStreak)
    }

    @Test
    fun testIsoDateParsingAndFormatting() {
        val validDate = "2026-10-25"
        val parsed = DateUtils.parseIso(validDate)
        assertNotNull(parsed)

        val invalidDate = "2026-99-99"
        // Should parse or handle safely without crashing
        val display = DateUtils.formatForDisplay("2026-10-25")
        assertNotNull(display)
    }

    @Test
    fun testTimeDisplayFormatting() {
        val formatted = DateUtils.formatTimeDisplay("14:30")
        assertEquals("02:30 PM", formatted)

        val morning = DateUtils.formatTimeDisplay("09:05")
        assertEquals("09:05 AM", morning)
    }

    @Test
    fun testTimerTimestampMath() {
        val targetDurationSeconds = 25 * 60
        val now = 1000000L
        val targetEndTime = now + (targetDurationSeconds * 1000L)

        // Halfway
        val currentTime = now + (10 * 60 * 1000L)
        val remaining = ((targetEndTime - currentTime + 999) / 1000).toInt()
        assertEquals(15 * 60, remaining)
    }

    @Test
    fun testVnAssistantFocusCommandParsing() {
        val intent25 = com.example.assistant.VnCommandEngine.parseCommand("start a 25-minute focus session")
        assert(intent25 is com.example.assistant.VnAssistantIntent.StartFocus)
        assertEquals(25, (intent25 as com.example.assistant.VnAssistantIntent.StartFocus).minutes)

        val intent45 = com.example.assistant.VnCommandEngine.parseCommand("focus for 45 minutes")
        assert(intent45 is com.example.assistant.VnAssistantIntent.StartFocus)
        assertEquals(45, (intent45 as com.example.assistant.VnAssistantIntent.StartFocus).minutes)

        val pauseIntent = com.example.assistant.VnCommandEngine.parseCommand("pause timer")
        assertEquals(com.example.assistant.VnAssistantIntent.PauseFocus, pauseIntent)
    }

    @Test
    fun testVnAssistantNotesCommandParsing() {
        val noteIntent = com.example.assistant.VnCommandEngine.parseCommand("create note about science project")
        assert(noteIntent is com.example.assistant.VnAssistantIntent.CreateNote)
        assertEquals("Science project", (noteIntent as com.example.assistant.VnAssistantIntent.CreateNote).title)

        val searchIntent = com.example.assistant.VnCommandEngine.parseCommand("find note homework")
        assert(searchIntent is com.example.assistant.VnAssistantIntent.FindNotes)
        assertEquals("homework", (searchIntent as com.example.assistant.VnAssistantIntent.FindNotes).query)
    }

    @Test
    fun testVnAssistantMultilingualHindiCommands() {
        val hindiFocus = com.example.assistant.VnCommandEngine.parseCommand("फोकस शुरू करो", "hi")
        assert(hindiFocus is com.example.assistant.VnAssistantIntent.StartFocus)

        val hindiNote = com.example.assistant.VnCommandEngine.parseCommand("नोट्स खोलो", "hi")
        assert(hindiNote is com.example.assistant.VnAssistantIntent.NavigateTo)
        assertEquals(com.example.ui.NavTab.NOTES, (hindiNote as com.example.assistant.VnAssistantIntent.NavigateTo).tab)

        val hinglishHabit = com.example.assistant.VnCommandEngine.parseCommand("reading habit complete karo", "hi")
        assert(hinglishHabit is com.example.assistant.VnAssistantIntent.CompleteHabit)
    }

    @Test
    fun testVnAssistantMultilingualSpanishCommands() {
        val spanishFocus = com.example.assistant.VnCommandEngine.parseCommand("iniciar temporizador de 15 minutos", "es")
        assert(spanishFocus is com.example.assistant.VnAssistantIntent.StartFocus)
        assertEquals(15, (spanishFocus as com.example.assistant.VnAssistantIntent.StartFocus).minutes)

        val spanishNotes = com.example.assistant.VnCommandEngine.parseCommand("abrir notas", "es")
        assert(spanishNotes is com.example.assistant.VnAssistantIntent.NavigateTo)
    }

    @Test
    fun testVnAssistantWelcomeVoiceTrigger() {
        val welcomeIntent = com.example.assistant.VnCommandEngine.parseCommand("meet vnhit please")
        assertEquals(com.example.assistant.VnAssistantIntent.PlayWelcomeGreeting, welcomeIntent)
    }
}
